package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.ProductDao;
import com.yellow.eatandsip.model.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/customer/wishlist")
public class WishlistServlet extends HttpServlet {
    private final ProductDao productDao = new ProductDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        List<Product> wishlist = (List<Product>) session.getAttribute("wishlist");
        if (wishlist == null) wishlist = new ArrayList<>();
        req.setAttribute("wishlist", wishlist);
        req.getRequestDispatcher("/customer/wishlist.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        String action = req.getParameter("action");
        List<Product> wishlist = (List<Product>) session.getAttribute("wishlist");
        if (wishlist == null) wishlist = new ArrayList<>();
        try {
            int productId = Integer.parseInt(req.getParameter("productId"));
            if ("add".equals(action)) {
                Product product = productDao.findById(productId);
                if (product != null && wishlist.stream().noneMatch(p -> p.getProductId() == productId)) {
                    wishlist.add(product);
                    session.setAttribute("wishlist", wishlist);
                    String msg = URLEncoder.encode("❤️ Product added to wishlist!", StandardCharsets.UTF_8);
                    resp.sendRedirect(req.getContextPath() + "/customer/dashboard?message=" + msg);
                    return;
                } else {
                    String err = URLEncoder.encode("Product already in wishlist.", StandardCharsets.UTF_8);
                    resp.sendRedirect(req.getContextPath() + "/customer/dashboard?error=" + err);
                    return;
                }
            } else if ("remove".equals(action)) {
                wishlist.removeIf(p -> p.getProductId() == productId);
                session.setAttribute("wishlist", wishlist);
                resp.sendRedirect(req.getContextPath() + "/customer/wishlist");
                return;
            }
        } catch (Exception e) {
            String err = URLEncoder.encode(e.getMessage(), StandardCharsets.UTF_8);
            resp.sendRedirect(req.getContextPath() + "/customer/dashboard?error=" + err);
            return;
        }
        resp.sendRedirect(req.getContextPath() + "/customer/wishlist");
    }
}