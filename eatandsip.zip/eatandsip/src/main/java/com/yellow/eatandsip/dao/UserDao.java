package com.yellow.eatandsip.dao;

import com.yellow.eatandsip.config.Dbconfig;
import com.yellow.eatandsip.model.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDao {

    public boolean usernameExists(String username) throws Exception {
        String sql = "SELECT id FROM users WHERE username = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    public boolean emailExists(String email) throws Exception {
        String sql = "SELECT id FROM users WHERE email = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    public boolean register(User user) throws Exception {
        String sql = "INSERT INTO users (username, email, password, role, status, phone, address) VALUES (?, ?, ?, 'customer', 'pending', ?, ?)";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getPhone());
            ps.setString(5, user.getAddress());
            return ps.executeUpdate() == 1;
        }
    }

    public User findByEmail(String email) throws Exception {
        String sql = "SELECT id, username, email, password, role, status, phone, address FROM users WHERE email = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs, true);
            }
        }
        return null;
    }

    public User findById(int id) throws Exception {
        String sql = "SELECT id, username, email, password, role, status, phone, address FROM users WHERE id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs, true);
            }
        }
        return null;
    }

    public void updatePasswordHash(int userId, String hash) throws Exception {
        String sql = "UPDATE users SET password = ? WHERE id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, hash);
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
    }

    public List<User> findAllUsers() throws Exception {
        String sql = "SELECT id, username, email, role, status, phone, address FROM users ORDER BY id DESC";
        List<User> list = new ArrayList<>();
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs, false));
        }
        return list;
    }

    public void updateUserStatus(int userId, String status) throws Exception {
        String sql = "UPDATE users SET status = ? WHERE id = ? AND role = 'customer'";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
    }

    public void updateUserRole(int userId, String role) throws Exception {
        String sql = "UPDATE users SET role = ? WHERE id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, role);
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
    }

    public void updateProfile(User user) throws Exception {
        String sql = "UPDATE users SET username = ?, email = ?, phone = ?, address = ? WHERE id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPhone());
            ps.setString(4, user.getAddress());
            ps.setInt(5, user.getId());
            ps.executeUpdate();
        }
    }

    public void changePassword(int userId, String hash) throws Exception {
        String sql = "UPDATE users SET password = ? WHERE id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, hash);
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
    }

    private User map(ResultSet rs, boolean includePassword) throws Exception {
        User u = new User();
        u.setId(rs.getInt("id"));
        u.setUsername(rs.getString("username"));
        u.setEmail(rs.getString("email"));
        u.setRole(rs.getString("role"));
        u.setStatus(rs.getString("status"));
        u.setPhone(rs.getString("phone"));
        u.setAddress(rs.getString("address"));
        if (includePassword) u.setPassword(rs.getString("password"));
        return u;
    }
        // Get total number of customers (role = 'customer')
    public int getTotalCustomers() throws Exception {
        String sql = "SELECT COUNT(*) FROM users WHERE role = 'customer'";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        }
        return 0;
    }
}