package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.CategoryDao;
import com.yellow.eatandsip.model.Category;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/categories")
public class AdminCategoryServlet extends HttpServlet {
    private CategoryDao dao = new CategoryDao();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String action = req.getParameter("action");
            if ("edit".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                req.setAttribute("category", dao.findById(id));
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                dao.deactivate(id);
                req.setAttribute("message", "Category deactivated.");
            }
            req.setAttribute("categories", dao.findAll());
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
        }
        req.getRequestDispatcher("/admin/categories.jsp").forward(req, resp);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            Category c = new Category();
            String id = req.getParameter("categoryId");
            c.setCategoryName(req.getParameter("categoryName").trim());
            c.setDescription(req.getParameter("description"));
            c.setImageUrl(req.getParameter("imageUrl"));
            c.setActive("on".equals(req.getParameter("active")));
            if (id == null || id.isBlank()) dao.save(c);
            else { c.setCategoryId(Integer.parseInt(id)); dao.update(c); }
            resp.sendRedirect(req.getContextPath() + "/admin/categories");
        } catch (Exception e) {
            req.setAttribute("error", "Save error: " + e.getMessage());
            doGet(req, resp);
        }
    }
}