package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.UserDao;
import com.yellow.eatandsip.model.User;
import com.yellow.eatandsip.util.PasswordUtil;
import com.yellow.eatandsip.util.ValidationUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private UserDao userDao = new UserDao();
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect(req.getContextPath() + "/login.jsp");
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        req.setAttribute("email", email);
        String error = ValidationUtil.validateLogin(email, password);
        if (error != null) {
            req.setAttribute("error", error);
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
            return;
        }
        try {
            User user = userDao.findByEmail(email.trim().toLowerCase());
            if (user == null || !PasswordUtil.verifyPassword(password, user.getPassword())) {
                req.setAttribute("error", "Invalid email or password.");
                req.getRequestDispatcher("/login.jsp").forward(req, resp);
                return;
            }
            if (!"approved".equalsIgnoreCase(user.getStatus())) {
                req.setAttribute("error", "Account not approved yet.");
                req.getRequestDispatcher("/login.jsp").forward(req, resp);
                return;
            }
            if (!PasswordUtil.isBcryptHash(user.getPassword())) {
                userDao.updatePasswordHash(user.getId(), PasswordUtil.hashPassword(password));
            }
            HttpSession session = req.getSession();
            session.setAttribute("userId", user.getId());
            session.setAttribute("username", user.getUsername());
            session.setAttribute("email", user.getEmail());
            session.setAttribute("role", user.getRole());
            session.setMaxInactiveInterval(30 * 60);
            Cookie remember = new Cookie("rememberEmail", user.getEmail());
            remember.setMaxAge(7 * 24 * 60 * 60);
            remember.setHttpOnly(true);
            resp.addCookie(remember);
            if ("admin".equalsIgnoreCase(user.getRole())) {
                resp.sendRedirect(req.getContextPath() + "/admin/dashboard.jsp");
            } else {
                resp.sendRedirect(req.getContextPath() + "/customer/dashboard");
            }
        } catch (Exception e) {
            req.setAttribute("error", "Login error: " + e.getMessage());
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        }
    }
}