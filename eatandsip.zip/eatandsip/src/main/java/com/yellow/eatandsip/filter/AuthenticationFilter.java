package com.yellow.eatandsip.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/*")
public class AuthenticationFilter implements Filter {
    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        String uri = request.getRequestURI();
        String contextPath = request.getContextPath();

        // Allow public resources and pages
        if (uri.endsWith(".css") || uri.endsWith(".jpg") || uri.endsWith(".png") || uri.endsWith(".js") ||
            uri.endsWith("login.jsp") || uri.endsWith("register.jsp") || uri.endsWith("about.jsp") ||
            uri.endsWith("contact.jsp") || uri.endsWith("error.jsp") || uri.endsWith("products") ||
            uri.contains("/login") || uri.contains("/register") || uri.contains("/contact") ||
            uri.equals(contextPath + "/") || uri.equals(contextPath + "/products") || uri.equals(contextPath + "/logout")) {
            chain.doFilter(request, response);
            return;
        }

        HttpSession session = request.getSession(false);
        String role = (session != null) ? (String) session.getAttribute("role") : null;

        if (role == null) {
            response.sendRedirect(contextPath + "/login.jsp");
            return;
        }

        if (uri.contains("/admin/") && !"admin".equalsIgnoreCase(role)) {
            response.sendRedirect(contextPath + "/error.jsp");
            return;
        }
        if (uri.contains("/customer/") && !"customer".equalsIgnoreCase(role)) {
            response.sendRedirect(contextPath + "/error.jsp");
            return;
        }
        chain.doFilter(request, response);
    }
}