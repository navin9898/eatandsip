package com.yellow.eatandsip.dao;

import com.yellow.eatandsip.config.Dbconfig;
import com.yellow.eatandsip.model.Product;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDao {

    public List<Product> findAll(String keyword) throws Exception {
        String sql = "SELECT p.product_id, p.category_id, c.category_name, p.name, p.description, p.price, "
                + "p.stock_quantity, p.image_url FROM products p JOIN categories c ON p.category_id = c.category_id "
                + "WHERE (? IS NULL OR p.name LIKE ? OR c.category_name LIKE ?) ORDER BY p.product_id DESC";
        List<Product> list = new ArrayList<>();
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String search = (keyword == null || keyword.trim().isEmpty()) ? null : "%" + keyword.trim() + "%";
            ps.setString(1, search);
            ps.setString(2, search);
            ps.setString(3, search);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    public Product findById(int id) throws Exception {
        String sql = "SELECT p.product_id, p.category_id, c.category_name, p.name, p.description, p.price, "
                + "p.stock_quantity, p.image_url FROM products p JOIN categories c ON p.category_id = c.category_id "
                + "WHERE p.product_id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    public void save(Product p) throws Exception {
        String sql = "INSERT INTO products (category_id, name, description, price, stock_quantity, image_url) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            fill(ps, p);
            ps.executeUpdate();
        }
    }

    public void update(Product p) throws Exception {
        String sql = "UPDATE products SET category_id = ?, name = ?, description = ?, price = ?, stock_quantity = ?, image_url = ? WHERE product_id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            fill(ps, p);
            ps.setInt(7, p.getProductId());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws Exception {
        String sql = "DELETE FROM products WHERE product_id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public void reduceStock(int productId, int quantity) throws Exception {
        String sql = "UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ? AND stock_quantity >= ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, quantity);
            ps.setInt(2, productId);
            ps.setInt(3, quantity);
            if (ps.executeUpdate() != 1) throw new Exception("Not enough stock.");
        }
    }

        public List<Product> getLowStockProducts(int threshold) throws Exception {
        String sql = "SELECT p.product_id, p.name, p.stock_quantity, c.category_name " +
                     "FROM products p JOIN categories c ON p.category_id = c.category_id " +
                     "WHERE p.stock_quantity < ?";
        List<Product> list = new ArrayList<>();
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, threshold);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Product p = new Product();
                    p.setProductId(rs.getInt("product_id"));
                    p.setName(rs.getString("name"));
                    p.setStockQuantity(rs.getInt("stock_quantity"));
                    p.setCategoryName(rs.getString("category_name"));
                    list.add(p);
                }
            }
        }
        return list;
    }

    private void fill(PreparedStatement ps, Product p) throws Exception {
        ps.setInt(1, p.getCategoryId());
        ps.setString(2, p.getName());
        ps.setString(3, p.getDescription());
        ps.setBigDecimal(4, p.getPrice());
        ps.setInt(5, p.getStockQuantity());
        ps.setString(6, p.getImageUrl());
    }

    private Product map(ResultSet rs) throws Exception {
        Product p = new Product();
        p.setProductId(rs.getInt("product_id"));
        p.setCategoryId(rs.getInt("category_id"));
        p.setCategoryName(rs.getString("category_name"));
        p.setName(rs.getString("name"));
        p.setDescription(rs.getString("description"));
        p.setPrice(rs.getBigDecimal("price"));
        p.setStockQuantity(rs.getInt("stock_quantity"));
        p.setImageUrl(rs.getString("image_url"));
        return p;
    }
        // Get total number of products
    public int getTotalProducts() throws Exception {
        String sql = "SELECT COUNT(*) FROM products";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        }
        return 0;
    }
    
}