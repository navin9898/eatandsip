package com.yellow.eatandsip.dao;

import com.yellow.eatandsip.config.Dbconfig;
import com.yellow.eatandsip.model.OrderRecord;
import com.yellow.eatandsip.model.Product;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class OrderDao {

    // Inner classes for report data
    public static class ProductSales {
        private String productName;
        private int totalSold;
        public String getProductName() { return productName; }
        public void setProductName(String name) { this.productName = name; }
        public int getTotalSold() { return totalSold; }
        public void setTotalSold(int sold) { this.totalSold = sold; }
    }

    public static class CategorySales {
        private String categoryName;
        private int totalSold;
        public String getCategoryName() { return categoryName; }
        public void setCategoryName(String name) { this.categoryName = name; }
        public int getTotalSold() { return totalSold; }
        public void setTotalSold(int sold) { this.totalSold = sold; }
    }

    public static class DailySale {
        private Date date;
        private double total;
        public Date getDate() { return date; }
        public void setDate(Date date) { this.date = date; }
        public double getTotal() { return total; }
        public void setTotal(double total) { this.total = total; }
    }

    // Create a single product order (one product per order)
    public int createSingleProductOrder(int userId, Product product, int quantity) throws Exception {
        BigDecimal total = product.getPrice().multiply(BigDecimal.valueOf(quantity));
        String orderSql = "INSERT INTO orders (user_id, total_amount, status) VALUES (?, ?, 'pending')";
        String itemSql = "INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)";
        try (Connection conn = Dbconfig.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement orderPs = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS);
                 PreparedStatement itemPs = conn.prepareStatement(itemSql)) {
                orderPs.setInt(1, userId);
                orderPs.setBigDecimal(2, total);
                orderPs.executeUpdate();
                int orderId;
                try (ResultSet keys = orderPs.getGeneratedKeys()) {
                    if (!keys.next()) throw new Exception("Order ID not generated.");
                    orderId = keys.getInt(1);
                }
                itemPs.setInt(1, orderId);
                itemPs.setInt(2, product.getProductId());
                itemPs.setInt(3, quantity);
                itemPs.setBigDecimal(4, product.getPrice());
                itemPs.executeUpdate();
                conn.commit();
                return orderId;
            } catch (Exception e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    // Get orders for a specific user
    public List<OrderRecord> findOrdersByUser(int userId) throws Exception {
        String sql = "SELECT o.order_id, o.total_amount, o.status, o.ordered_date, "
                + "p.name AS product_name, oi.quantity, oi.unit_price "
                + "FROM orders o "
                + "JOIN order_items oi ON o.order_id = oi.order_id "
                + "JOIN products p ON oi.product_id = p.product_id "
                + "WHERE o.user_id = ? ORDER BY o.ordered_date DESC";
        List<OrderRecord> list = new ArrayList<>();
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    OrderRecord o = new OrderRecord();
                    o.setOrderId(rs.getInt("order_id"));
                    o.setTotalAmount(rs.getBigDecimal("total_amount"));
                    o.setStatus(rs.getString("status"));
                    o.setOrderedDate(rs.getTimestamp("ordered_date"));
                    o.setProductName(rs.getString("product_name"));
                    o.setQuantity(rs.getInt("quantity"));
                    o.setUnitPrice(rs.getBigDecimal("unit_price"));
                    list.add(o);
                }
            }
        }
        return list;
    }

    // Get all orders (for admin)
    public List<OrderRecord> findAllOrders() throws Exception {
        String sql = "SELECT o.order_id, o.total_amount, o.status, o.ordered_date, o.user_id, "
                + "u.username, p.name AS product_name, oi.quantity, oi.unit_price "
                + "FROM orders o "
                + "JOIN users u ON o.user_id = u.id "
                + "JOIN order_items oi ON o.order_id = oi.order_id "
                + "JOIN products p ON oi.product_id = p.product_id "
                + "ORDER BY o.ordered_date DESC";
        List<OrderRecord> list = new ArrayList<>();
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                OrderRecord o = new OrderRecord();
                o.setOrderId(rs.getInt("order_id"));
                o.setTotalAmount(rs.getBigDecimal("total_amount"));
                o.setStatus(rs.getString("status"));
                o.setOrderedDate(rs.getTimestamp("ordered_date"));
                o.setUserId(rs.getInt("user_id"));
                o.setProductName(rs.getString("username") + " - " + rs.getString("product_name"));
                o.setQuantity(rs.getInt("quantity"));
                o.setUnitPrice(rs.getBigDecimal("unit_price"));
                list.add(o);
            }
        }
        return list;
    }

    // Update order status (admin)
    public void updateOrderStatus(int orderId, String status) throws Exception {
        String sql = "UPDATE orders SET status = ? WHERE order_id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, orderId);
            ps.executeUpdate();
        }
    }

    // Update delivery date (admin)
    public void updateDeliveryDate(int orderId, Date deliveryDate) throws Exception {
        String sql = "UPDATE orders SET delivery_date = ? WHERE order_id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, deliveryDate);
            ps.setInt(2, orderId);
            ps.executeUpdate();
        }
    }
    
        // Cancel order (customer)
    public void cancelOrder(int orderId) throws Exception {
        String sql = "UPDATE orders SET status = 'cancelled' WHERE order_id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, orderId);
            ps.executeUpdate();
        }
    }

    // Get count of orders for a user (for customer dashboard)
    public int getUserOrderCount(int userId) throws Exception {
        String sql = "SELECT COUNT(*) FROM orders WHERE user_id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return 0;
    }

    // Get most ordered product name for a user (for customer dashboard)
    public String getMostOrderedProductName(int userId) throws Exception {
        String sql = "SELECT p.name, SUM(oi.quantity) as total FROM orders o "
                + "JOIN order_items oi ON o.order_id = oi.order_id "
                + "JOIN products p ON oi.product_id = p.product_id "
                + "WHERE o.user_id = ? GROUP BY p.product_id ORDER BY total DESC LIMIT 1";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getString("name");
            }
        }
        return "None";
    }

    // Reports: Top selling products
    public List<ProductSales> getTopSellingProducts(int limit) throws Exception {
        String sql = "SELECT p.name, SUM(oi.quantity) as total_sold "
                + "FROM order_items oi JOIN products p ON oi.product_id = p.product_id "
                + "GROUP BY p.product_id ORDER BY total_sold DESC LIMIT ?";
        List<ProductSales> list = new ArrayList<>();
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ProductSales psales = new ProductSales();
                    psales.setProductName(rs.getString("name"));
                    psales.setTotalSold(rs.getInt("total_sold"));
                    list.add(psales);
                }
            }
        }
        return list;
    }

    // Reports: Sales by category
    public List<CategorySales> getSalesByCategory() throws Exception {
        String sql = "SELECT c.category_name, SUM(oi.quantity) as total_sold "
                + "FROM order_items oi JOIN products p ON oi.product_id = p.product_id "
                + "JOIN categories c ON p.category_id = c.category_id "
                + "GROUP BY c.category_id";
        List<CategorySales> list = new ArrayList<>();
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                CategorySales cs = new CategorySales();
                cs.setCategoryName(rs.getString("category_name"));
                cs.setTotalSold(rs.getInt("total_sold"));
                list.add(cs);
            }
        }
        return list;
    }

    // ==================== STATISTICS METHODS (ONLY ONCE) ====================

    // Total number of orders (for admin stats)
    public int getTotalOrders() throws Exception {
        String sql = "SELECT COUNT(*) FROM orders";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        }
        return 0;
    }

    // Total revenue (for admin stats)
    public double getTotalRevenue() throws Exception {
        String sql = "SELECT SUM(total_amount) FROM orders";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getDouble(1);
        }
        return 0.0;
    }

    // Total customers (for admin stats)
    public int getTotalCustomers() throws Exception {
        String sql = "SELECT COUNT(*) FROM users WHERE role = 'customer'";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        }
        return 0;
    }

    // Total products (for admin stats)
    public int getTotalProducts() throws Exception {
        String sql = "SELECT COUNT(*) FROM products";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        }
        return 0;
    }

    // Daily sales for last 7 days (for chart)
    public List<DailySale> getDailySalesLast7Days() throws Exception {
        String sql = "SELECT DATE(ordered_date) as sale_date, SUM(total_amount) as total "
                + "FROM orders WHERE ordered_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) "
                + "GROUP BY DATE(ordered_date) ORDER BY sale_date DESC";
        List<DailySale> list = new ArrayList<>();
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                DailySale ds = new DailySale();
                ds.setDate(rs.getDate("sale_date"));
                ds.setTotal(rs.getDouble("total"));
                list.add(ds);
            }
        }
        return list;
    }
}