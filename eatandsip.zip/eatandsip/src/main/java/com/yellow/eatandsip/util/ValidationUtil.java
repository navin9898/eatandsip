package com.yellow.eatandsip.util;

import java.util.regex.Pattern;

public class ValidationUtil {
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

    public static String validateRegistration(String username, String email, String password, String confirm) {
        if (username == null || username.trim().isEmpty()) return "Username required.";
        if (username.trim().length() < 3) return "Username min 3 chars.";
        if (!username.matches("^[A-Za-z][A-Za-z0-9_ ]*$")) return "Username must start with a letter.";
        if (email == null || email.trim().isEmpty()) return "Email required.";
        if (!EMAIL.matcher(email).matches()) return "Invalid email.";
        if (password == null || password.isEmpty()) return "Password required.";
        if (password.length() < 8) return "Password min 8 chars.";
        if (!password.matches(".*[A-Z].*") || !password.matches(".*[a-z].*") || !password.matches(".*[0-9].*"))
            return "Password must contain uppercase, lowercase, number.";
        if (!password.equals(confirm)) return "Passwords do not match.";
        return null;
    }

    public static String validateLogin(String email, String password) {
        if (email == null || email.trim().isEmpty()) return "Email required.";
        if (!EMAIL.matcher(email).matches()) return "Invalid email.";
        if (password == null || password.isEmpty()) return "Password required.";
        return null;
    }
}