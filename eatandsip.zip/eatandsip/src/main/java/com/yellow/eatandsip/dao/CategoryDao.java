package com.yellow.eatandsip.dao;

import com.yellow.eatandsip.config.Dbconfig;
import com.yellow.eatandsip.model.Category;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoryDao {

    public List<Category> findAll() throws Exception {
        String sql = "SELECT category_id, category_name, description, image_url, is_active FROM categories ORDER BY category_name";
        List<Category> list = new ArrayList<>();
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public List<Category> findActive() throws Exception {
        String sql = "SELECT category_id, category_name, description, image_url, is_active FROM categories WHERE is_active = 1 ORDER BY category_name";
        List<Category> list = new ArrayList<>();
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public Category findById(int id) throws Exception {
        String sql = "SELECT category_id, category_name, description, image_url, is_active FROM categories WHERE category_id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    public void save(Category c) throws Exception {
        String sql = "INSERT INTO categories (category_name, description, image_url, is_active) VALUES (?, ?, ?, 1)";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getCategoryName());
            ps.setString(2, c.getDescription());
            ps.setString(3, c.getImageUrl());
            ps.executeUpdate();
        }
    }

    public void update(Category c) throws Exception {
        String sql = "UPDATE categories SET category_name = ?, description = ?, image_url = ?, is_active = ? WHERE category_id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getCategoryName());
            ps.setString(2, c.getDescription());
            ps.setString(3, c.getImageUrl());
            ps.setBoolean(4, c.isActive());
            ps.setInt(5, c.getCategoryId());
            ps.executeUpdate();
        }
    }

    public void deactivate(int id) throws Exception {
        String sql = "UPDATE categories SET is_active = 0 WHERE category_id = ?";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    private Category map(ResultSet rs) throws Exception {
        Category c = new Category();
        c.setCategoryId(rs.getInt("category_id"));
        c.setCategoryName(rs.getString("category_name"));
        c.setDescription(rs.getString("description"));
        c.setImageUrl(rs.getString("image_url"));
        c.setActive(rs.getBoolean("is_active"));
        return c;
    }
}