package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.UserDao;
import com.yellow.eatandsip.model.User;
import com.yellow.eatandsip.util.PasswordUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/customer/profile")
public class CustomerProfileServlet extends HttpServlet {
    private UserDao userDao = new UserDao();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            resp.sendRedirect("login.jsp");
            return;
        }
        try {
            int userId = (Integer) session.getAttribute("userId");
            req.setAttribute("user", userDao.findById(userId));
            req.getRequestDispatcher("/customer/profile.jsp").forward(req, resp);
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
            req.getRequestDispatcher("/customer/profile.jsp").forward(req, resp);
        }
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            resp.sendRedirect("login.jsp");
            return;
        }
        int userId = (Integer) session.getAttribute("userId");
        try {
            String action = req.getParameter("action");
            if ("profile".equals(action)) {
                User u = new User();
                u.setId(userId);
                u.setUsername(req.getParameter("username").trim());
                u.setEmail(req.getParameter("email").trim().toLowerCase());
                u.setPhone(req.getParameter("phone"));
                u.setAddress(req.getParameter("address"));
                userDao.updateProfile(u);
                session.setAttribute("username", u.getUsername());
                session.setAttribute("email", u.getEmail());
                req.setAttribute("message", "Profile updated.");
            } else if ("password".equals(action)) {
                String newPass = req.getParameter("newPassword");
                String confirm = req.getParameter("confirmPassword");
                if (newPass == null || newPass.length() < 8) {
                    req.setAttribute("error", "Password min 8 chars.");
                } else if (!newPass.equals(confirm)) {
                    req.setAttribute("error", "Passwords do not match.");
                } else {
                    userDao.changePassword(userId, PasswordUtil.hashPassword(newPass));
                    req.setAttribute("message", "Password changed.");
                }
            }
            req.setAttribute("user", userDao.findById(userId));
            req.getRequestDispatcher("/customer/profile.jsp").forward(req, resp);
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
            doGet(req, resp);
        }
    }
}