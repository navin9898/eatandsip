package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.ProductDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/products")
public class ProductBrowseServlet extends HttpServlet {
    private ProductDao productDao = new ProductDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            String keyword = req.getParameter("keyword");
            req.setAttribute("keyword", keyword);
            req.setAttribute("products", productDao.findAll(keyword));
            req.getRequestDispatcher("/products.jsp").forward(req, resp);
        } catch (Exception e) {
            req.setAttribute("error", "Unable to load products: " + e.getMessage());
            req.getRequestDispatcher("/products.jsp").forward(req, resp);
        }
    }
}