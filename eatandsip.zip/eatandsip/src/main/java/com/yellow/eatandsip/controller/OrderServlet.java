package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.OrderDao;
import com.yellow.eatandsip.dao.ProductDao;
import com.yellow.eatandsip.model.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@WebServlet("/customer/order")
public class OrderServlet extends HttpServlet {
    private ProductDao productDao = new ProductDao();
    private OrderDao orderDao = new OrderDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect(req.getContextPath() + "/customer/dashboard?error=Invalid request.");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        int userId = (Integer) session.getAttribute("userId");
        try {
            int productId = Integer.parseInt(req.getParameter("productId"));
            int quantity = Integer.parseInt(req.getParameter("quantity"));
            if (quantity < 1) throw new Exception("Invalid quantity.");
            Product product = productDao.findById(productId);
            if (product == null) throw new Exception("Product not found.");
            if (quantity > product.getStockQuantity()) throw new Exception("Not enough stock.");
            productDao.reduceStock(productId, quantity);
            orderDao.createSingleProductOrder(userId, product, quantity);
            String message = URLEncoder.encode("✅ Order placed successfully!", StandardCharsets.UTF_8);
            resp.sendRedirect(req.getContextPath() + "/customer/dashboard?message=" + message);
        } catch (Exception e) {
            String error = URLEncoder.encode(e.getMessage(), StandardCharsets.UTF_8);
            resp.sendRedirect(req.getContextPath() + "/customer/dashboard?error=" + error);
        }
    }
}