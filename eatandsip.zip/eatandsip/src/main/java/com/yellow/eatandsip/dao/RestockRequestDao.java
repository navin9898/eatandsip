package com.yellow.eatandsip.dao;

import com.yellow.eatandsip.config.Dbconfig;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class RestockRequestDao {
    public void addRequest(int userId, int productId) throws Exception {
        String sql = "INSERT INTO restock_requests (user_id, product_id) VALUES (?, ?)";
        try (Connection conn = Dbconfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, productId);
            ps.executeUpdate();
        }
    }
}