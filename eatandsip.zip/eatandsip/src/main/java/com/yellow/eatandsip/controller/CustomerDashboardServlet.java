package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.OrderDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/customer/dashboard")
public class CustomerDashboardServlet extends HttpServlet {
    private OrderDao orderDao = new OrderDao();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            resp.sendRedirect("login.jsp");
            return;
        }
        int userId = (Integer) session.getAttribute("userId");
        try {
            req.setAttribute("orderCount", orderDao.getUserOrderCount(userId));
            req.setAttribute("mostOrdered", orderDao.getMostOrderedProductName(userId));
            req.getRequestDispatcher("/customer/dashboard.jsp").forward(req, resp);
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
            req.getRequestDispatcher("/customer/dashboard.jsp").forward(req, resp);
        }
    }
}