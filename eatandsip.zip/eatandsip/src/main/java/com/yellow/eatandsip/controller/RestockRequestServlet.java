package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.RestockRequestDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@WebServlet("/customer/requestRestock")
public class RestockRequestServlet extends HttpServlet {
    private RestockRequestDao dao = new RestockRequestDao();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            resp.sendRedirect("login.jsp");
            return;
        }
        int userId = (Integer) session.getAttribute("userId");
        int productId = Integer.parseInt(req.getParameter("productId"));
        try {
            dao.addRequest(userId, productId);
            String msg = URLEncoder.encode("Restock request sent.", StandardCharsets.UTF_8);
            resp.sendRedirect(req.getContextPath() + "/customer/dashboard?message=" + msg);
        } catch (Exception e) {
            String err = URLEncoder.encode(e.getMessage(), StandardCharsets.UTF_8);
            resp.sendRedirect(req.getContextPath() + "/customer/dashboard?error=" + err);
        }
    }
}