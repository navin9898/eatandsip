package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.CategoryDao;
import com.yellow.eatandsip.dao.ProductDao;
import com.yellow.eatandsip.model.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;

@WebServlet("/admin/products")
public class AdminProductServlet extends HttpServlet {
    private ProductDao productDao = new ProductDao();
    private CategoryDao categoryDao = new CategoryDao();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String action = req.getParameter("action");
            if ("edit".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                req.setAttribute("product", productDao.findById(id));
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                productDao.delete(id);
                req.setAttribute("message", "Product deleted.");
            }
            req.setAttribute("categories", categoryDao.findActive());
            req.setAttribute("products", productDao.findAll(req.getParameter("keyword")));
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
        }
        req.getRequestDispatcher("/admin/products.jsp").forward(req, resp);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            Product p = new Product();
            String id = req.getParameter("productId");
            p.setCategoryId(Integer.parseInt(req.getParameter("categoryId")));
            p.setName(req.getParameter("name").trim());
            p.setDescription(req.getParameter("description").trim());
            p.setPrice(new BigDecimal(req.getParameter("price")));
            p.setStockQuantity(Integer.parseInt(req.getParameter("stockQuantity")));
            p.setImageUrl(req.getParameter("imageUrl"));
            if (id == null || id.isBlank()) productDao.save(p);
            else { p.setProductId(Integer.parseInt(id)); productDao.update(p); }
            resp.sendRedirect(req.getContextPath() + "/admin/products");
        } catch (Exception e) {
            req.setAttribute("error", "Save error: " + e.getMessage());
            doGet(req, resp);
        }
    }
}