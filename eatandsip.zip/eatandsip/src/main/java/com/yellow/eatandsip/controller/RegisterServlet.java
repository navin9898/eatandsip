package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.UserDao;
import com.yellow.eatandsip.model.User;
import com.yellow.eatandsip.util.PasswordUtil;
import com.yellow.eatandsip.util.ValidationUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private UserDao userDao = new UserDao();
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect(req.getContextPath() + "/register.jsp");
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String confirm = req.getParameter("confirmPassword");
        String phone = req.getParameter("phone");
        String address = req.getParameter("address");
        req.setAttribute("username", username);
        req.setAttribute("email", email);
        String error = ValidationUtil.validateRegistration(username, email, password, confirm);
        if (error != null) {
            req.setAttribute("error", error);
            req.getRequestDispatcher("/register.jsp").forward(req, resp);
            return;
        }
        try {
            if (userDao.usernameExists(username.trim())) {
                req.setAttribute("error", "Username exists.");
                req.getRequestDispatcher("/register.jsp").forward(req, resp);
                return;
            }
            if (userDao.emailExists(email.trim().toLowerCase())) {
                req.setAttribute("error", "Email exists.");
                req.getRequestDispatcher("/register.jsp").forward(req, resp);
                return;
            }
            User user = new User();
            user.setUsername(username.trim());
            user.setEmail(email.trim().toLowerCase());
            user.setPassword(PasswordUtil.hashPassword(password));
            user.setPhone(phone);
            user.setAddress(address);
            if (userDao.register(user)) {
                req.setAttribute("success", "Registered! Wait for admin approval.");
                req.getRequestDispatcher("/login.jsp").forward(req, resp);
            } else {
                req.setAttribute("error", "Registration failed.");
                req.getRequestDispatcher("/register.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
            req.getRequestDispatcher("/register.jsp").forward(req, resp);
        }
    }
}