package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.UserDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/users")
public class AdminUserServlet extends HttpServlet {
    private UserDao userDao = new UserDao();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String action = req.getParameter("action");
            String idParam = req.getParameter("id");
            if (action != null && idParam != null) {
                int id = Integer.parseInt(idParam);
                switch (action) {
                    case "approve": userDao.updateUserStatus(id, "approved"); break;
                    case "reject": userDao.updateUserStatus(id, "rejected"); break;
                    case "makeAdmin": userDao.updateUserRole(id, "admin"); userDao.updateUserStatus(id, "approved"); break;
                    case "makeCustomer": userDao.updateUserRole(id, "customer"); break;
                }
                req.setAttribute("message", "User updated.");
            }
            req.setAttribute("users", userDao.findAllUsers());
            req.getRequestDispatcher("/admin/users.jsp").forward(req, resp);
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
            req.getRequestDispatcher("/admin/users.jsp").forward(req, resp);
        }
    }
}