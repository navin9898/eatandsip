package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.OrderDao;
import com.yellow.eatandsip.dao.ProductDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/reports")
public class AdminReportServlet extends HttpServlet {
    private OrderDao orderDao = new OrderDao();
    private ProductDao productDao = new ProductDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            // Statistics for cards
            req.setAttribute("totalProducts", productDao.getTotalProducts());
            req.setAttribute("totalOrders", orderDao.getTotalOrders());
            req.setAttribute("totalCustomers", orderDao.getTotalCustomers());
            req.setAttribute("totalRevenue", orderDao.getTotalRevenue());

            // Report tables
            req.setAttribute("topProducts", orderDao.getTopSellingProducts(5));
            req.setAttribute("lowStockProducts", productDao.getLowStockProducts(10));
            req.setAttribute("categorySales", orderDao.getSalesByCategory());
            req.setAttribute("dailySales", orderDao.getDailySalesLast7Days());

            req.getRequestDispatcher("/admin/reports.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Report error: " + e.getMessage());
            req.getRequestDispatcher("/admin/reports.jsp").forward(req, resp);
        }
    }
}