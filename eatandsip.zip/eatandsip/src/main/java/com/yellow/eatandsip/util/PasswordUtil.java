package com.yellow.eatandsip.util;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordUtil {
    public static String hashPassword(String plain) { return BCrypt.hashpw(plain, BCrypt.gensalt(10)); }
    public static boolean isBcryptHash(String stored) { return stored != null && (stored.startsWith("$2a$") || stored.startsWith("$2b$") || stored.startsWith("$2y$")); }
    public static boolean verifyPassword(String plain, String stored) {
        if (plain == null || stored == null) return false;
        if (isBcryptHash(stored)) return BCrypt.checkpw(plain, stored);
        return plain.equals(stored); // fallback for plain text (upgrade later)
    }
}