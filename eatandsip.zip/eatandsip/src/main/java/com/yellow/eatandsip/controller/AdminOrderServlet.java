package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.OrderDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;

@WebServlet("/admin/orders")
public class AdminOrderServlet extends HttpServlet {
    private OrderDao orderDao = new OrderDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String action = req.getParameter("action");
            if ("updateStatus".equals(action) && req.getParameter("orderId") != null) {
                int oid = Integer.parseInt(req.getParameter("orderId"));
                orderDao.updateOrderStatus(oid, req.getParameter("status"));
                String delivery = req.getParameter("deliveryDate");
                if (delivery != null && !delivery.isEmpty()) {
                    orderDao.updateDeliveryDate(oid, Date.valueOf(delivery));
                }
                req.setAttribute("message", "Order updated.");
            }
            req.setAttribute("orders", orderDao.findAllOrders());
            req.getRequestDispatcher("/admin/orders.jsp").forward(req, resp);
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
            req.getRequestDispatcher("/admin/orders.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}