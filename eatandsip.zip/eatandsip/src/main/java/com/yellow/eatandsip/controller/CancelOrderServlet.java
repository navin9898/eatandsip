package com.yellow.eatandsip.controller;

import com.yellow.eatandsip.dao.OrderDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@WebServlet("/customer/cancelOrder")
public class CancelOrderServlet extends HttpServlet {
    private OrderDao orderDao = new OrderDao();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        try {
            int orderId = Integer.parseInt(req.getParameter("orderId"));
            orderDao.cancelOrder(orderId);
            String msg = URLEncoder.encode("Order #" + orderId + " cancelled.", StandardCharsets.UTF_8);
            resp.sendRedirect(req.getContextPath() + "/customer/orders?message=" + msg);
        } catch (Exception e) {
            String err = URLEncoder.encode(e.getMessage(), StandardCharsets.UTF_8);
            resp.sendRedirect(req.getContextPath() + "/customer/orders?error=" + err);
        }
    }
}