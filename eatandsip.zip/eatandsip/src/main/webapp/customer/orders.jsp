<%@ page import="java.util.List" %>
<%@ page import="com.yellow.eatandsip.model.OrderRecord" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    List<OrderRecord> orders = (List<OrderRecord>) request.getAttribute("orders");
%>
<!DOCTYPE html>
<html>
<head>
    <title>My Orders - Eat&Sip</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f3ea;
            color: #20332a;
        }
        .topbar {
            display: flex;
            justify-content: space-between;
            padding: 18px 7%;
            background: white;
            border-bottom: 1px solid #ddd3c1;
        }
        .brand { font-size: 26px; font-weight: bold; color: #276749; }
        .nav a { margin-left: 15px; color: #276749; text-decoration: none; }
        .page { width: 90%; max-width: 1100px; margin: 30px auto; }
        .panel {
            background: white;
            border: 1px solid #ddd3c1;
            border-radius: 8px;
            padding: 22px;
            box-shadow: 0 8px 22px rgba(35, 45, 39, 0.08);
            overflow-x: auto;
        }
        table { width: 100%; border-collapse: collapse; }
        th, td { border-bottom: 1px solid #ddd3c1; padding: 12px; text-align: left; }
        th { background: #eef4ef; }
        .status {
            font-weight: bold;
            padding: 5px 8px;
            border-radius: 5px;
            background: #fff8df;
            color: #856404;
        }
        .status.delivered { background: #d4edda; color: #155724; }
        .status.cancelled { background: #f8d7da; color: #721c24; }
        .error { background: #fff1f0; color: #9b1c1c; padding: 10px; border-radius: 6px; margin-bottom: 15px; }
        .success { background: #edf9f1; color: #1f6f3f; padding: 10px; border-radius: 6px; margin-bottom: 15px; }
        .cancel-btn {
            background: #dc3545;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
        }
        .cancel-btn:hover { background: #c82333; }
        .disabled { background: #6c757d; cursor: not-allowed; }
    </style>
</head>
<body>
    
    
<header class="topbar">
    <div class="brand">Eat&amp;Sip</div>
    <nav class="nav">
        <a href="${pageContext.request.contextPath}/customer/dashboard">Dashboard</a>
        <a href="${pageContext.request.contextPath}/customer/profile">My Profile</a>
        <a href="${pageContext.request.contextPath}/products">Products</a>
        <a href="${pageContext.request.contextPath}/logout">Logout</a>
    </nav>
</header>
<main class="page">
    <h1>My Orders</h1>
    <% if (request.getParameter("message") != null) { %>
        <div class="success"><%= request.getParameter("message") %></div>
    <% } %>
    <% if (request.getParameter("error") != null) { %>
        <div class="error"><%= request.getParameter("error") %></div>
    <% } %>
    <section class="panel">
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total Amount</th>
                    <th>Status</th>
                    <th>Order Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <% if (orders != null && !orders.isEmpty()) {
                    for (OrderRecord order : orders) { %>
                        <tr>
                            <td><%= order.getOrderId() %></td>
                            <td><%= order.getProductName() %></td>
                            <td><%= order.getQuantity() %></td>
                            <td>Rs. <%= order.getUnitPrice() %></td>
                            <td>Rs. <%= order.getTotalAmount() %></td>
                            <td>
                                <span class="status 
                                    <%= "delivered".equals(order.getStatus()) ? "delivered" : "" %>
                                    <%= "cancelled".equals(order.getStatus()) ? "cancelled" : "" %>">
                                    <%= order.getStatus() %>
                                </span>
                            </td>
                            <td><%= order.getOrderedDate() %></td>
                            <td>
                                <% if ("pending".equals(order.getStatus())) { %>
                                    <form action="${pageContext.request.contextPath}/customer/cancelOrder" method="post" 
                                          onsubmit="return confirm('Are you sure you want to cancel this order?')">
                                        <input type="hidden" name="orderId" value="<%= order.getOrderId() %>">
                                        <button type="submit" class="cancel-btn">Cancel Order</button>
                                    </form>
                                <% } else { %>
                                    <span class="disabled" style="color:#999;">—</span>
                                <% } %>
                            </td>
                        </tr>
                <%   }
                } else { %>
                    <tr><td colspan="8">No orders found.</td></tr>
                <% } %>
            </tbody>
        </table>
    </section>
</main>
</body>
</html>