<%@ page import="com.yellow.eatandsip.model.User" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%
    User user = (User) request.getAttribute("user");
%>

<!DOCTYPE html>
<html>
<head>
    <title>My Profile - Eat&Sip</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f3ea;
            color: #20332a;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            padding: 18px 7%;
            background: white;
            border-bottom: 1px solid #ddd3c1;
        }

        .brand {
            font-size: 26px;
            font-weight: bold;
            color: #276749;
        }

        .nav a {
            margin-left: 15px;
            color: #276749;
            font-weight: bold;
            text-decoration: none;
        }

        .page {
            width: 90%;
            max-width: 1000px;
            margin: 30px auto;
        }

        .layout {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 22px;
        }

        .panel {
            background: white;
            border: 1px solid #ddd3c1;
            border-radius: 8px;
            padding: 22px;
            box-shadow: 0 8px 22px rgba(35, 45, 39, 0.08);
        }

        label {
            display: block;
            margin-top: 12px;
            font-weight: bold;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            border: 1px solid #c9d2cb;
            border-radius: 6px;
            box-sizing: border-box;
        }

        textarea {
            min-height: 90px;
        }

        button {
            margin-top: 14px;
            background: #276749;
            color: white;
            border: 0;
            padding: 10px 14px;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
        }

        .success {
            background: #edf9f1;
            color: #1f6f3f;
            border: 1px solid #a8ddb8;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .error {
            background: #fff1f0;
            color: #9b1c1c;
            border: 1px solid #f3b2ad;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        @media (max-width: 800px) {
            .layout {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    

<header class="topbar">
    <div class="brand">Eat&amp;Sip</div>

    <nav class="nav">
        <a href="${pageContext.request.contextPath}/customer/dashboard.jsp">Dashboard</a>
        <a href="${pageContext.request.contextPath}/products">Products</a>
        <a href="${pageContext.request.contextPath}/customer/orders">My Orders</a>
        <a href="${pageContext.request.contextPath}/logout">Logout</a>
    </nav>
</header>

<main class="page">
    <h1>My Profile</h1>

    <% if (request.getAttribute("message") != null) { %>
        <div class="success"><%= request.getAttribute("message") %></div>
    <% } %>

    <% if (request.getAttribute("error") != null) { %>
        <div class="error"><%= request.getAttribute("error") %></div>
    <% } %>

    <section class="layout">
        <div class="panel">
            <h2>Profile Details</h2>

            <form method="post" action="${pageContext.request.contextPath}/customer/profile">
                <input type="hidden" name="action" value="profile">

                <label>Username</label>
                <input name="username" required value="<%= user == null ? "" : user.getUsername() %>">

                <label>Email</label>
                <input type="email" name="email" required value="<%= user == null ? "" : user.getEmail() %>">

                <label>Phone</label>
                <input name="phone" value="<%= user == null || user.getPhone() == null ? "" : user.getPhone() %>">

                <label>Address</label>
                <textarea name="address"><%= user == null || user.getAddress() == null ? "" : user.getAddress() %></textarea>

                <button type="submit">Update Profile</button>
            </form>
        </div>

        <div class="panel">
            <h2>Change Password</h2>

            <form method="post" action="${pageContext.request.contextPath}/customer/profile">
                <input type="hidden" name="action" value="password">

                <label>New Password</label>
                <input type="password" name="newPassword" required>

                <label>Confirm Password</label>
                <input type="password" name="confirmPassword" required>

                <button type="submit">Change Password</button>
            </form>
        </div>
    </section>
</main>

</body>
</html>