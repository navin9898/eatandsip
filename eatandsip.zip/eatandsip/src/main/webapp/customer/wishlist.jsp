<%@ page import="java.util.List" %>
<%@ page import="com.yellow.eatandsip.model.Product" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%
    List<Product> wishlist = (List<Product>) request.getAttribute("wishlist");
%>

<!DOCTYPE html>
<html>
<head>
    <title>My Wishlist - Eat&Sip</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f3ea;
            color: #20332a;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            padding: 18px 7%;
            background: white;
            border-bottom: 1px solid #ddd3c1;
        }

        .brand {
            font-size: 26px;
            font-weight: bold;
            color: #276749;
        }

        .nav a {
            margin-left: 15px;
            color: #276749;
            font-weight: bold;
            text-decoration: none;
        }

        .page {
            width: 90%;
            max-width: 1100px;
            margin: 30px auto;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
            gap: 18px;
        }

        .card {
            background: white;
            border: 1px solid #ddd3c1;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 8px 22px rgba(35, 45, 39, 0.08);
        }

        .card h3 {
            margin-top: 0;
        }

        .muted {
            color: #61736b;
        }

        .price {
            font-size: 20px;
            font-weight: bold;
            color: #276749;
        }

        button, .button {
            display: inline-block;
            margin-top: 10px;
            background: #276749;
            color: white;
            padding: 10px 14px;
            border: 0;
            border-radius: 6px;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
        }

        .danger {
            background: #a33a2d;
        }

        .panel {
            background: white;
            border: 1px solid #ddd3c1;
            border-radius: 8px;
            padding: 22px;
        }
    </style>
</head>
<body>
    

<header class="topbar">
    <div class="brand">Eat&amp;Sip</div>

    <nav class="nav">
        <a href="${pageContext.request.contextPath}/customer/dashboard.jsp">Dashboard</a>
        <a href="${pageContext.request.contextPath}/products">Products</a>
        <a href="${pageContext.request.contextPath}/customer/profile">My Profile</a>
        <a href="${pageContext.request.contextPath}/customer/orders">My Orders</a>
        <a href="${pageContext.request.contextPath}/logout">Logout</a>
    </nav>
</header>

<main class="page">
    <h1>My Wishlist</h1>

    <% if (request.getParameter("error") != null) { %>
        <div class="panel"><%= request.getParameter("error") %></div>
    <% } %>

    <% if (wishlist != null && !wishlist.isEmpty()) { %>
        <section class="grid">
            <% for (Product product : wishlist) { %>
                <article class="card">
                    <p class="muted"><%= product.getCategoryName() %></p>
                    <h3><%= product.getName() %></h3>
                    <p><%= product.getDescription() %></p>
                    <p class="price">Rs. <%= product.getPrice() %></p>
                    <p class="muted">Stock: <%= product.getStockQuantity() %></p>

                    <form method="post" action="${pageContext.request.contextPath}/customer/wishlist">
                        <input type="hidden" name="action" value="remove">
                        <input type="hidden" name="productId" value="<%= product.getProductId() %>">
                        <button class="danger" type="submit">Remove</button>
                    </form>
                </article>
            <% } %>
        </section>
    <% } else { %>
        <section class="panel">
            <p>Your wishlist is empty.</p>
            <a class="button" href="${pageContext.request.contextPath}/products">Browse Products</a>
        </section>
    <% } %>
</main>

</body>
</html>