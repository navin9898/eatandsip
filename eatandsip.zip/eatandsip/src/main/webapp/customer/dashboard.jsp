<%@ page import="java.util.List" %>
<%@ page import="com.yellow.eatandsip.model.Product" %>
<%@ page import="com.yellow.eatandsip.dao.ProductDao" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    ProductDao productDao = new ProductDao();
    List<Product> products = productDao.findAll(null);
    Integer userId = (Integer) session.getAttribute("userId");
    String username = (String) session.getAttribute("username");
%>
<!DOCTYPE html>
<html>
<head><title>Customer Dashboard - Eat&Sip</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',sans-serif;background:#f8f9fa}
.header{background:white;box-shadow:0 2px 10px rgba(0,0,0,0.05);position:sticky;top:0}
.top-bar{max-width:1280px;margin:0 auto;padding:15px 20px;display:flex;justify-content:space-between;flex-wrap:wrap}
.logo{font-size:28px;font-weight:bold;color:#2e7d32;text-decoration:none}
.nav-links{display:flex;gap:20px}
.nav-links a{text-decoration:none;color:#333}
.btn-logout{background:#f44336;color:white!important;padding:8px 16px;border-radius:30px}
.container{max-width:1280px;margin:30px auto;padding:0 20px}
.welcome-card{background:linear-gradient(135deg,#2e7d32,#4caf50);border-radius:20px;padding:30px;margin-bottom:30px;color:white}
.section-title{font-size:24px;margin:20px 0;border-left:4px solid #2e7d32;padding-left:15px}
.message{background:#d4edda;color:#155724;padding:12px;border-radius:10px;margin-bottom:20px}
.error-message{background:#f8d7da;color:#721c24;padding:12px;border-radius:10px;margin-bottom:20px}
.product-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:25px}
.product-card{background:white;border-radius:16px;overflow:hidden;transition:0.3s;box-shadow:0 2px 8px rgba(0,0,0,0.05)}
.product-card:hover{transform:translateY(-5px)}
.product-img{width:100%;height:160px;object-fit:cover}
.product-info{padding:16px}
.product-price{font-size:20px;font-weight:bold;color:#2e7d32}
.btn-order,.btn-wishlist{padding:8px 16px;border-radius:30px;border:none;cursor:pointer}
.btn-order{background:#2e7d32;color:white}
.btn-wishlist{background:#fff3e0;color:#ff9800}
.quantity-input{width:60px;padding:6px;border:1px solid #ddd;border-radius:20px}
@media(max-width:768px){.top-bar{flex-direction:column}}
</style>
</head>
<body>
    
    
<header class="header"><div class="top-bar">
<a href="${pageContext.request.contextPath}/customer/dashboard" class="logo">Eat&amp;Sip</a>
<div class="nav-links">
<a href="${pageContext.request.contextPath}/customer/dashboard">Dashboard</a>
<a href="${pageContext.request.contextPath}/customer/wishlist">Wishlist</a>
<a href="${pageContext.request.contextPath}/customer/orders">My Orders</a>
<a href="${pageContext.request.contextPath}/about.jsp">About</a>
<a href="${pageContext.request.contextPath}/contact.jsp">Contact</a>
<a href="${pageContext.request.contextPath}/logout" class="btn-logout">Logout</a>
</div></div></header>
<div class="container">
<div class="welcome-card"><h1>Welcome back, <%= username %>!</h1><p>Fresh groceries delivered.</p></div>
<%
    String msg = request.getParameter("message");
    String err = request.getParameter("error");
    if (msg != null && !msg.isEmpty()) { %><div class="message"><%= msg %></div><% }
    if (err != null && !err.isEmpty()) { %><div class="error-message"><%= err %></div><% }
%>
<div class="section-title"><h2>🛒 Our Fresh Products</h2></div>
<div class="product-grid">
<% if (products == null || products.isEmpty()) { %><p>No products available.</p>
<% } else { for (Product p : products) { %>
<div class="product-card">
<img class="product-img" src="<%= p.getImageUrl() != null ? p.getImageUrl() : "https://via.placeholder.com/300x160" %>" alt="<%= p.getName() %>">
<div class="product-info">
<div class="product-category"><%= p.getCategoryName() %></div>
<div class="product-name"><%= p.getName() %></div>
<div class="product-price">Rs. <%= p.getPrice() %></div>
<div class="product-stock">Stock: <%= p.getStockQuantity() %></div>
<div class="product-actions">
<% if (p.getStockQuantity() > 0) { %>
<form action="${pageContext.request.contextPath}/customer/order" method="post" style="display:flex; gap:5px;">
<input type="hidden" name="productId" value="<%= p.getProductId() %>">
<input type="number" name="quantity" value="1" min="1" max="<%= p.getStockQuantity() %>" class="quantity-input">
<button type="submit" class="btn-order">Order</button>
</form>
<% } else { %>
<form action="${pageContext.request.contextPath}/customer/requestRestock" method="post">
<input type="hidden" name="productId" value="<%= p.getProductId() %>">
<button type="submit" style="background:#ff9800;color:white;border:none;padding:8px 16px;border-radius:30px;">Notify Me</button>
</form>
<% } %>
<form action="${pageContext.request.contextPath}/customer/wishlist" method="post">
<input type="hidden" name="action" value="add">
<input type="hidden" name="productId" value="<%= p.getProductId() %>">
<button type="submit" class="btn-wishlist">♥ Wishlist</button>
</form>
</div></div></div>
<% } } %>
</div></div>
</body></html>