<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Error - Eat&Sip</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f3ea;
            color: #21302a;
        }

        .page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }

        .box {
            width: 100%;
            max-width: 520px;
            background: white;
            border: 1px solid #ddd3c1;
            border-radius: 8px;
            padding: 32px;
            text-align: center;
            box-shadow: 0 10px 28px rgba(0,0,0,0.10);
        }

        h1 {
            color: #a33a2d;
            margin-bottom: 10px;
        }

        p {
            color: #66736b;
            font-size: 18px;
        }

        a {
            display: inline-block;
            margin-top: 18px;
            background: #276749;
            color: white;
            padding: 12px 18px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>
   

<div class="page">
    <div class="box">
        <h1>Something went wrong</h1>

        <p>
            The page you are trying to access is unavailable, or you do not have permission to view it.
        </p>

        <a href="${pageContext.request.contextPath}/products">Back to Eat&Sip</a>
    </div>
</div>

</body>
</html>