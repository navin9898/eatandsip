<%@ page import="java.util.List" %>
<%@ page import="com.yellow.eatandsip.model.Category" %>
<%@ page import="com.yellow.eatandsip.model.Product" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%
    List<Category> categories = (List<Category>) request.getAttribute("categories");
    List<Product> products = (List<Product>) request.getAttribute("products");
    Product editing = (Product) request.getAttribute("product");
%>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Products - Eat&Sip Admin</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f3ea;
            color: #20332a;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            padding: 18px 7%;
            background: white;
            border-bottom: 1px solid #ddd3c1;
        }

        .brand {
            font-size: 26px;
            font-weight: bold;
            color: #276749;
        }

        .nav a {
            margin-left: 15px;
            color: #276749;
            font-weight: bold;
            text-decoration: none;
        }

        .page {
            width: 90%;
            max-width: 1150px;
            margin: 30px auto;
        }

        .panel {
            background: white;
            border: 1px solid #ddd3c1;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-top: 12px;
            font-weight: bold;
        }

        input, textarea, select {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            border: 1px solid #c9d2cb;
            border-radius: 6px;
            box-sizing: border-box;
        }

        button, .button {
            display: inline-block;
            margin-top: 12px;
            background: #276749;
            color: white;
            padding: 10px 14px;
            border: 0;
            border-radius: 6px;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
        }

        .danger {
            background: #a33a2d;
        }

        .secondary {
            background: #6b766f;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        th, td {
            border-bottom: 1px solid #ddd3c1;
            padding: 12px;
            text-align: left;
        }

        th {
            background: #eef4ef;
        }

        .error {
            background: #fff1f0;
            color: #9b1c1c;
            border: 1px solid #f3b2ad;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .success {
            background: #edf9f1;
            color: #1f6f3f;
            border: 1px solid #a8ddb8;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 14px;
        }
    </style>
</head>
<body>
    

<header class="topbar">
    <div class="brand">Eat&amp;Sip Admin</div>
    <nav class="nav">
        <a href="${pageContext.request.contextPath}/admin/dashboard.jsp">Dashboard</a>
        <a href="${pageContext.request.contextPath}/admin/categories">Categories</a>
        <a href="${pageContext.request.contextPath}/admin/products">Products</a>
        <a href="${pageContext.request.contextPath}/admin/users">Users</a>
        <a href="${pageContext.request.contextPath}/admin/orders">Orders</a>
        <a href="${pageContext.request.contextPath}/admin/reports">Reports</a>
        <a href="${pageContext.request.contextPath}/products">Store</a>
        <a href="${pageContext.request.contextPath}/logout">Logout</a>
    </nav>
</header>

<main class="page">
    <h1>Product Management</h1>

    <% if (request.getAttribute("message") != null) { %>
        <div class="success"><%= request.getAttribute("message") %></div>
    <% } %>

    <% if (request.getAttribute("error") != null) { %>
        <div class="error"><%= request.getAttribute("error") %></div>
    <% } %>

    <section class="panel">
        <h2><%= editing == null ? "Add Product" : "Edit Product" %></h2>

        <form method="post" action="${pageContext.request.contextPath}/admin/products">
            <input type="hidden" name="productId" value="<%= editing == null ? "" : editing.getProductId() %>">

            <div class="row">
                <div>
                    <label>Category</label>
                    <select name="categoryId" required>
                        <% if (categories != null) {
                            for (Category category : categories) { %>
                                <option value="<%= category.getCategoryId() %>"
                                    <%= editing != null && editing.getCategoryId() == category.getCategoryId() ? "selected" : "" %>>
                                    <%= category.getCategoryName() %>
                                </option>
                        <%  }
                        } %>
                    </select>
                </div>

                <div>
                    <label>Product Name</label>
                    <input name="name" required value="<%= editing == null ? "" : editing.getName() %>">
                </div>

                <div>
                    <label>Price</label>
                    <input type="number" step="0.01" min="0" name="price" required value="<%= editing == null ? "" : editing.getPrice() %>">
                </div>

                <div>
                    <label>Stock Quantity</label>
                    <input type="number" min="0" name="stockQuantity" required value="<%= editing == null ? "" : editing.getStockQuantity() %>">
                </div>
            </div>

            <label>Description</label>
            <textarea name="description" required><%= editing == null ? "" : editing.getDescription() %></textarea>

            <label>Image URL</label>
            <input name="imageUrl" value="<%= editing == null || editing.getImageUrl() == null ? "" : editing.getImageUrl() %>">

            <button type="submit">Save Product</button>

            <% if (editing != null) { %>
                <a class="button secondary" href="${pageContext.request.contextPath}/admin/products">Cancel Edit</a>
            <% } %>
        </form>
    </section>

    <section class="panel">
        <h2>Product List</h2>

        <form method="get" action="${pageContext.request.contextPath}/admin/products">
            <div class="row">
                <input name="keyword" value="${param.keyword}" placeholder="Search product or category">
                <button type="submit">Search</button>
            </div>
        </form>

        <table style="margin-top: 16px;">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <% if (products != null && !products.isEmpty()) {
                    for (Product product : products) { %>
                        <tr>
                            <td><%= product.getProductId() %></td>
                            <td><%= product.getName() %></td>
                            <td><%= product.getCategoryName() %></td>
                            <td>Rs. <%= product.getPrice() %></td>
                            <td><%= product.getStockQuantity() %></td>
                            <td>
                                <a class="button secondary" href="${pageContext.request.contextPath}/admin/products?action=edit&id=<%= product.getProductId() %>">Edit</a>
                                <a class="button danger" href="${pageContext.request.contextPath}/admin/products?action=delete&id=<%= product.getProductId() %>" onclick="return confirm('Delete this product?')">Delete</a>
                            </td>
                        </tr>
                <%  }
                } else { %>
                    <tr>
                        <td colspan="6">No products found.</td>
                    </tr>
                <% } %>
            </tbody>
        </table>
    </section>
</main>

</body>
</html>