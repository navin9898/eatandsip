<%@ page import="java.util.List" %>
<%@ page import="com.yellow.eatandsip.dao.OrderDao" %>
<%@ page import="com.yellow.eatandsip.model.Product" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    Integer totalProducts = (Integer) request.getAttribute("totalProducts");
    Integer totalOrders = (Integer) request.getAttribute("totalOrders");
    Integer totalCustomers = (Integer) request.getAttribute("totalCustomers");
    Double totalRevenue = (Double) request.getAttribute("totalRevenue");
    List<OrderDao.ProductSales> topProducts = (List<OrderDao.ProductSales>) request.getAttribute("topProducts");
    List<Product> lowStockProducts = (List<Product>) request.getAttribute("lowStockProducts");
    List<OrderDao.CategorySales> categorySales = (List<OrderDao.CategorySales>) request.getAttribute("categorySales");
    List<OrderDao.DailySale> dailySales = (List<OrderDao.DailySale>) request.getAttribute("dailySales");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Reports - Eat&Sip Analytics</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f4f6f9; }
        .sidebar { width: 260px; background: #1e2a3a; color: white; position: fixed; height: 100%; padding: 20px; }
        .sidebar h2 { color: #ff9800; margin-bottom: 30px; }
        .sidebar a { display: block; color: #ccc; text-decoration: none; padding: 10px; margin: 5px 0; border-radius: 8px; }
        .sidebar a:hover, .sidebar a.active { background: #2e7d32; color: white; }
        .main { margin-left: 260px; padding: 20px; }
        .top-bar { background: white; padding: 15px 20px; border-radius: 12px; margin-bottom: 25px; display: flex; justify-content: space-between; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px,1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 16px; text-align: center; }
        .stat-number { font-size: 32px; font-weight: bold; color: #2e7d32; }
        .panel { background: white; border-radius: 16px; padding: 20px; margin-bottom: 30px; }
        .panel h2 { margin-bottom: 15px; border-left: 4px solid #2e7d32; padding-left: 12px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ecf0f1; }
        th { background: #eef2f7; }
        .badge { background: #ff9800; color: white; padding: 4px 10px; border-radius: 20px; }
        .chart-container { max-width: 100%; height: 350px; margin-bottom: 20px; }
        @media (max-width: 768px) { .sidebar { width: 100%; height: auto; position: relative; } .main { margin-left: 0; } }
    </style>
</head>
<body>
    
<div class="sidebar">
    <h2>Eat&amp;Sip Admin</h2>
    <a href="${pageContext.request.contextPath}/admin/dashboard.jsp">Dashboard</a>
    <a href="${pageContext.request.contextPath}/admin/categories">Categories</a>
    <a href="${pageContext.request.contextPath}/admin/products">Products</a>
    <a href="${pageContext.request.contextPath}/admin/users">Users</a>
    <a href="${pageContext.request.contextPath}/admin/orders">Orders</a>
    <a href="${pageContext.request.contextPath}/admin/reports" class="active">Reports</a>
    <a href="${pageContext.request.contextPath}/logout">Logout</a>
</div>
<div class="main">
    <div class="top-bar">
        <h2>Analytics & Reports</h2>
        <div><%= new java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a").format(new java.util.Date()) %></div>
    </div>
    <div class="stats-grid">
        <div class="stat-card"><div class="stat-number"><%= totalProducts != null ? totalProducts : 0 %></div><div>Total Products</div></div>
        <div class="stat-card"><div class="stat-number"><%= totalOrders != null ? totalOrders : 0 %></div><div>Total Orders</div></div>
        <div class="stat-card"><div class="stat-number"><%= totalCustomers != null ? totalCustomers : 0 %></div><div>Total Customers</div></div>
        <div class="stat-card"><div class="stat-number">Rs. <%= String.format("%.2f", totalRevenue != null ? totalRevenue : 0.0) %></div><div>Total Revenue</div></div>
    </div>
    <div class="panel"><h2>📈 Top 5 Selling Products</h2>
        <table><thead><tr><th>Product</th><th>Quantity Sold</th></tr></thead>
        <tbody><% if (topProducts != null) for (OrderDao.ProductSales ps : topProducts) { %>
            <tr><td><%= ps.getProductName() %></td><td><%= ps.getTotalSold() %></td></tr>
        <% } %></tbody></table>
    </div>
    <div class="panel"><h2>⚠️ Low Stock Products (Stock < 10)</h2>
        <table><thead><tr><th>Product</th><th>Stock</th></tr></thead>
        <tbody><% if (lowStockProducts != null) for (Product p : lowStockProducts) { %>
            <tr><td><%= p.getName() %></td><td><span class="badge"><%= p.getStockQuantity() %></span></td></tr>
        <% } %></tbody></table>
    </div>
    <div class="panel"><h2>📊 Sales by Category</h2>
        <table><thead><tr><th>Category</th><th>Items Sold</th></tr></thead>
        <tbody><% if (categorySales != null) for (OrderDao.CategorySales cs : categorySales) { %>
            <tr><td><%= cs.getCategoryName() %></td><td><%= cs.getTotalSold() %></td></tr>
        <% } %></tbody></table>
    </div>
    <div class="panel"><h2>📅 Daily Sales Trend (Last 7 Days)</h2>
        <div class="chart-container"><canvas id="salesChart"></canvas></div>
    </div>
</div>
<script>
    const dailyData = [
        <% if (dailySales != null) for (OrderDao.DailySale ds : dailySales) { %>
            { date: "<%= ds.getDate() %>", sales: <%= ds.getTotal() %> },
        <% } %>
    ];
    const labels = dailyData.map(d => d.date);
    const sales = dailyData.map(d => d.sales);
    new Chart(document.getElementById("salesChart"), {
        type: 'bar',
        data: { labels: labels, datasets: [{ label: 'Daily Sales (Rs.)', data: sales, backgroundColor: '#2e7d32' }] },
        options: { responsive: true, maintainAspectRatio: true }
    });
</script>
</body>
</html>