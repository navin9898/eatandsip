<%@ page import="java.util.List" %>
<%@ page import="com.yellow.eatandsip.model.Category" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%
    List<Category> categories = (List<Category>) request.getAttribute("categories");
    Category editing = (Category) request.getAttribute("category");
%>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Categories - Eat&Sip</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f3ea;
            color: #20332a;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            padding: 18px 7%;
            background: white;
            border-bottom: 1px solid #ddd3c1;
        }

        .brand {
            font-size: 26px;
            font-weight: bold;
            color: #276749;
        }

        .nav a {
            margin-left: 15px;
            color: #276749;
            font-weight: bold;
            text-decoration: none;
        }

        .page {
            width: 90%;
            max-width: 1100px;
            margin: 30px auto;
        }

        .panel {
            background: white;
            border: 1px solid #ddd3c1;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-top: 12px;
            font-weight: bold;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            border: 1px solid #c9d2cb;
            border-radius: 6px;
            box-sizing: border-box;
        }

        button, .button {
            display: inline-block;
            margin-top: 12px;
            background: #276749;
            color: white;
            padding: 10px 14px;
            border: 0;
            border-radius: 6px;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
        }

        .danger {
            background: #a33a2d;
        }

        .secondary {
            background: #6b766f;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        th, td {
            border-bottom: 1px solid #ddd3c1;
            padding: 12px;
            text-align: left;
        }

        th {
            background: #eef4ef;
        }

        .error {
            background: #fff1f0;
            color: #9b1c1c;
            border: 1px solid #f3b2ad;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .success {
            background: #edf9f1;
            color: #1f6f3f;
            border: 1px solid #a8ddb8;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
   

<header class="topbar">
    <div class="brand">Eat&amp;Sip Admin</div>
    <nav class="nav">
        <a href="${pageContext.request.contextPath}/admin/dashboard.jsp">Dashboard</a>
        <a href="${pageContext.request.contextPath}/admin/products">Products</a>
        <a href="${pageContext.request.contextPath}/products">Store</a>
        <a href="${pageContext.request.contextPath}/logout">Logout</a>
    </nav>
</header>

<main class="page">
    <h1>Category Management</h1>

    <% if (request.getAttribute("message") != null) { %>
        <div class="success"><%= request.getAttribute("message") %></div>
    <% } %>

    <% if (request.getAttribute("error") != null) { %>
        <div class="error"><%= request.getAttribute("error") %></div>
    <% } %>

    <section class="panel">
        <h2><%= editing == null ? "Add Category" : "Edit Category" %></h2>

        <form method="post" action="${pageContext.request.contextPath}/admin/categories">
            <input type="hidden" name="categoryId" value="<%= editing == null ? "" : editing.getCategoryId() %>">

            <label>Category Name</label>
            <input name="categoryName" required value="<%= editing == null ? "" : editing.getCategoryName() %>">

            <label>Description</label>
            <textarea name="description"><%= editing == null || editing.getDescription() == null ? "" : editing.getDescription() %></textarea>

            <label>Image URL</label>
            <input name="imageUrl" value="<%= editing == null || editing.getImageUrl() == null ? "" : editing.getImageUrl() %>">

            <label>
                <input type="checkbox" name="active" <%= editing == null || editing.isActive() ? "checked" : "" %> style="width:auto;">
                Active
            </label>

            <button type="submit">Save Category</button>

            <% if (editing != null) { %>
                <a class="button secondary" href="${pageContext.request.contextPath}/admin/categories">Cancel Edit</a>
            <% } %>
        </form>
    </section>

    <section class="panel">
        <h2>Category List</h2>

        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>

            <% if (categories != null && !categories.isEmpty()) {
                for (Category category : categories) { %>

                <tr>
                    <td><%= category.getCategoryId() %></td>
                    <td><%= category.getCategoryName() %></td>
                    <td><%= category.getDescription() %></td>
                    <td><%= category.isActive() ? "Active" : "Inactive" %></td>
                    <td>
                        <a class="button secondary" href="${pageContext.request.contextPath}/admin/categories?action=edit&id=<%= category.getCategoryId() %>">Edit</a>
                        <a class="button danger" href="${pageContext.request.contextPath}/admin/categories?action=delete&id=<%= category.getCategoryId() %>">Deactivate</a>
                    </td>
                </tr>

            <%  }
            } else { %>
                <tr>
                    <td colspan="5">No categories found.</td>
                </tr>
            <% } %>
        </table>
    </section>
</main>

</body>
</html>
