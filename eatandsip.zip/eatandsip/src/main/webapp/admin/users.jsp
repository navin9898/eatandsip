<%@ page import="java.util.List" %>
<%@ page import="com.yellow.eatandsip.model.User" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%
    List<User> users = (List<User>) request.getAttribute("users");
%>

<!DOCTYPE html>
<html>
<head>
    <title>User Management - Eat&Sip</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f3ea;
            color: #20332a;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            padding: 18px 7%;
            background: white;
            border-bottom: 1px solid #ddd3c1;
        }

        .brand {
            font-size: 26px;
            font-weight: bold;
            color: #276749;
        }

        .nav a {
            margin-left: 15px;
            color: #276749;
            font-weight: bold;
            text-decoration: none;
        }

        .page {
            width: 90%;
            max-width: 1150px;
            margin: 30px auto;
        }

        .panel {
            background: white;
            border: 1px solid #ddd3c1;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        th, td {
            border-bottom: 1px solid #ddd3c1;
            padding: 12px;
            text-align: left;
        }

        th {
            background: #eef4ef;
        }

        .button {
            display: inline-block;
            margin: 4px;
            background: #276749;
            color: white;
            padding: 8px 12px;
            border-radius: 6px;
            font-weight: bold;
            text-decoration: none;
        }

        .danger {
            background: #a33a2d;
        }

        .secondary {
            background: #6b766f;
        }

        .status {
            font-weight: bold;
            padding: 5px 8px;
            border-radius: 5px;
        }

        .approved {
            background: #edf9f1;
            color: #1f6f3f;
        }

        .pending {
            background: #fff8df;
            color: #856404;
        }

        .rejected {
            background: #fff1f0;
            color: #9b1c1c;
        }

        .success {
            background: #edf9f1;
            color: #1f6f3f;
            border: 1px solid #a8ddb8;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .error {
            background: #fff1f0;
            color: #9b1c1c;
            border: 1px solid #f3b2ad;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    
    

<header class="topbar">
    <div class="brand">Eat&amp;Sip Admin</div>

    <nav class="nav">
        <a href="${pageContext.request.contextPath}/admin/dashboard.jsp">Dashboard</a>
        <a href="${pageContext.request.contextPath}/admin/categories">Categories</a>
        <a href="${pageContext.request.contextPath}/admin/products">Products</a>
        <a href="${pageContext.request.contextPath}/products">Store</a>
        <a href="${pageContext.request.contextPath}/logout">Logout</a>
    </nav>
</header>

<main class="page">
    <h1>User Management</h1>

    <% if (request.getAttribute("message") != null) { %>
        <div class="success"><%= request.getAttribute("message") %></div>
    <% } %>

    <% if (request.getAttribute("error") != null) { %>
        <div class="error"><%= request.getAttribute("error") %></div>
    <% } %>

    <section class="panel">
        <h2>Registered Users</h2>

        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>

            <% if (users != null && !users.isEmpty()) {
                for (User user : users) { %>

                <tr>
                    <td><%= user.getId() %></td>
                    <td><%= user.getUsername() %></td>
                    <td><%= user.getEmail() %></td>
                    <td><%= user.getRole() %></td>
                    <td>
                        <span class="status <%= user.getStatus() %>">
                            <%= user.getStatus() %>
                        </span>
                    </td>
                    <td>
                        <% if ("pending".equalsIgnoreCase(user.getStatus())) { %>
                            <a class="button" href="${pageContext.request.contextPath}/admin/users?action=approve&id=<%= user.getId() %>">Approve</a>
                            <a class="button danger" href="${pageContext.request.contextPath}/admin/users?action=reject&id=<%= user.getId() %>">Reject</a>
                        <% } %>

                        <% if ("customer".equalsIgnoreCase(user.getRole())) { %>
                            <a class="button secondary" href="${pageContext.request.contextPath}/admin/users?action=makeAdmin&id=<%= user.getId() %>">Make Admin</a>
                        <% } else { %>
                            <a class="button secondary" href="${pageContext.request.contextPath}/admin/users?action=makeCustomer&id=<%= user.getId() %>">Make Customer</a>
                        <% } %>
                    </td>
                </tr>

            <%  }
            } else { %>
                <tr>
                    <td colspan="6">No users found.</td>
                </tr>
            <% } %>
        </table>
    </section>
</main>

</body>
</html>