<%@ page import="java.util.List" %>
<%@ page import="com.yellow.eatandsip.model.OrderRecord" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    List<OrderRecord> orders = (List<OrderRecord>) request.getAttribute("orders");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Orders - Eat&Sip Admin</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f4f6f9; }
        .sidebar { width: 260px; background: #1e2a3a; color: white; position: fixed; height: 100%; padding: 20px; }
        .sidebar a { display: block; color: #ccc; text-decoration: none; padding: 10px; margin: 5px 0; border-radius: 8px; }
        .sidebar a:hover, .sidebar a.active { background: #2e7d32; color: white; }
        .main { margin-left: 260px; padding: 20px; }
        .panel { background: white; border-radius: 16px; padding: 20px; overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ecf0f1; }
        th { background: #eef2f7; }
        select, input, button { padding: 6px 10px; border-radius: 6px; border: 1px solid #ccc; }
        button { background: #2e7d32; color: white; border: none; cursor: pointer; }
        .success { background: #d4edda; padding: 12px; border-radius: 8px; margin-bottom: 20px; }
        .error { background: #f8d7da; padding: 12px; border-radius: 8px; margin-bottom: 20px; }
        @media (max-width:768px){ .sidebar { width:100%; height:auto; position:relative; } .main { margin-left:0; } }
    </style>
</head>
<body>
   
<div class="sidebar">
    <h2>Eat&amp;Sip Admin</h2>
    <a href="${pageContext.request.contextPath}/admin/dashboard.jsp">Dashboard</a>
    <a href="${pageContext.request.contextPath}/admin/categories">Categories</a>
    <a href="${pageContext.request.contextPath}/admin/products">Products</a>
    <a href="${pageContext.request.contextPath}/admin/users">Users</a>
    <a href="${pageContext.request.contextPath}/admin/orders" class="active">Orders</a>
    <a href="${pageContext.request.contextPath}/admin/reports">Reports</a>
    <a href="${pageContext.request.contextPath}/logout">Logout</a>
</div>
<div class="main">
    <h2>Order Management</h2>
    <% if (request.getAttribute("message") != null) { %>
        <div class="success"><%= request.getAttribute("message") %></div>
    <% } %>
    <% if (request.getAttribute("error") != null) { %>
        <div class="error"><%= request.getAttribute("error") %></div>
    <% } %>
    <div class="panel">
        <table>
            <thead><tr><th>Order ID</th><th>Customer</th><th>Product</th><th>Qty</th><th>Total</th><th>Status</th><th>Order Date</th><th>Delivery Date</th><th>Update</th></tr></thead>
            <tbody>
            <% if (orders != null) for (com.yellow.eatandsip.model.OrderRecord ord : orders) {
                String[] parts = ord.getProductName().split(" - ");
                String customer = parts.length > 0 ? parts[0] : "Unknown";
                String product = parts.length > 1 ? parts[1] : ord.getProductName();
            %>
                <form method="post" action="${pageContext.request.contextPath}/admin/orders">
                    <input type="hidden" name="orderId" value="<%= ord.getOrderId() %>">
                    <input type="hidden" name="action" value="updateStatus">
                    <tr>
                        <td><%= ord.getOrderId() %></td><td><%= customer %></td><td><%= product %></td>
                        <td><%= ord.getQuantity() %></td><td>Rs. <%= ord.getTotalAmount() %></td>
                        <td><select name="status">
                            <option <%= "pending".equals(ord.getStatus()) ? "selected" : "" %>>pending</option>
                            <option <%= "confirmed".equals(ord.getStatus()) ? "selected" : "" %>>confirmed</option>
                            <option <%= "delivered".equals(ord.getStatus()) ? "selected" : "" %>>delivered</option>
                            <option <%= "cancelled".equals(ord.getStatus()) ? "selected" : "" %>>cancelled</option>
                        </select></td>
                        <td><%= ord.getOrderedDate() %></td>
                        <td><input type="date" name="deliveryDate"></td>
                        <td><button type="submit">Update</button></td>
                    </tr>
                </form>
            <% } %>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>