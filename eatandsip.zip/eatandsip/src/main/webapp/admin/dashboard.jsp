<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - Eat&Sip</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f4f6f9;
            color: #2c3e50;
        }

        /* Sidebar */
        .sidebar {
            width: 260px;
            background: #1e2a3a;
            color: white;
            position: fixed;
            height: 100%;
            padding: 20px;
            overflow-y: auto;
        }

        .sidebar h2 {
            color: #ff9800;
            margin-bottom: 30px;
            font-size: 24px;
        }

        .sidebar a {
            display: block;
            color: #ccc;
            text-decoration: none;
            padding: 12px;
            margin: 5px 0;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .sidebar a:hover, .sidebar a.active {
            background: #2e7d32;
            color: white;
        }

        /* Main content */
        .main {
            margin-left: 260px;
            padding: 20px;
        }

        /* Top bar */
        .top-bar {
            background: white;
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .welcome {
            font-size: 20px;
            font-weight: 600;
        }

        .date {
            color: #7f8c8d;
        }

        /* Stats cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 16px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            transition: transform 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-3px);
        }

        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #2e7d32;
        }

        .stat-label {
            color: #7f8c8d;
            margin-top: 8px;
        }

        /* Quick actions panel */
        .quick-actions {
            background: white;
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .quick-actions h3 {
            margin-bottom: 15px;
            border-left: 4px solid #2e7d32;
            padding-left: 12px;
        }

        .action-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }

        .action-btn {
            background: #2e7d32;
            color: white;
            padding: 10px 20px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 500;
            transition: background 0.3s;
        }

        .action-btn:hover {
            background: #1b5e20;
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 20px;
            color: #7f8c8d;
            border-top: 1px solid #ecf0f1;
            margin-top: 20px;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    
<div class="sidebar">
    <h2>Eat&amp;Sip<br><span style="font-size:14px;">Admin Panel</span></h2>
    <a href="${pageContext.request.contextPath}/admin/dashboard.jsp" class="active">Dashboard</a>
    <a href="${pageContext.request.contextPath}/admin/categories">Categories</a>
    <a href="${pageContext.request.contextPath}/admin/products">Products</a>
    <a href="${pageContext.request.contextPath}/admin/users">Users</a>
    <a href="${pageContext.request.contextPath}/admin/orders">Orders</a>
    <a href="${pageContext.request.contextPath}/admin/reports">Reports</a>
    <a href="${pageContext.request.contextPath}/products">View Store</a>
    <a href="${pageContext.request.contextPath}/logout">Logout</a>
</div>

<div class="main">
    <div class="top-bar">
        <div class="welcome">Welcome, ${sessionScope.username}!</div>
        <div class="date"><%= new java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a").format(new java.util.Date()) %></div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-number">0</div>
            <div class="stat-label">Total Orders</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">0</div>
            <div class="stat-label">Total Products</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">0</div>
            <div class="stat-label">Total Customers</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">0</div>
            <div class="stat-label">Pending Approvals</div>
        </div>
    </div>

    <div class="quick-actions">
        <h3>Quick Actions</h3>
        <div class="action-buttons">
            <a href="${pageContext.request.contextPath}/admin/categories" class="action-btn">Manage Categories</a>
            <a href="${pageContext.request.contextPath}/admin/products" class="action-btn">Manage Products</a>
            <a href="${pageContext.request.contextPath}/admin/users" class="action-btn">Approve Users</a>
            <a href="${pageContext.request.contextPath}/admin/orders" class="action-btn">View Orders</a>
            <a href="${pageContext.request.contextPath}/admin/reports" class="action-btn">View Reports</a>
        </div>
    </div>

    <div class="quick-actions">
        <h3>Store Information</h3>
        <p style="margin-bottom:10px;">Eat&amp;Sip is a grocery delivery platform. Use the menu to manage inventory, users, and orders.</p>
        <p>📧 support@eatandsip.com &nbsp;|&nbsp; 📞 +977-9800000000</p>
    </div>

    <div class="footer">
        <p>&copy; 2026 Eat&amp;Sip – Admin Dashboard</p>
    </div>
</div>
</body>
</html>