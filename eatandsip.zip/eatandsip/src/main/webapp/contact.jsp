<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String role = (String) session.getAttribute("role");
    String submitted = request.getParameter("submitted");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Contact Us - Eat&Sip</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f8f9fa; }
        .header {
            background: white;
            padding: 15px 7%;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .logo {
            font-size: 28px;
            font-weight: bold;
            color: #2e7d32;
            text-decoration: none;
        }
        .logo span { color: #ff9800; }
        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-links a:hover { color: #2e7d32; }
        .btn-login, .btn-register, .btn-dashboard, .btn-logout {
            padding: 8px 16px;
            border-radius: 30px;
            font-weight: 600;
        }
        .btn-login { background: #2e7d32; color: white !important; }
        .btn-login:hover { background: #1b5e20; }
        .btn-register { background: #ff9800; color: white !important; }
        .btn-register:hover { background: #e68900; }
        .btn-dashboard { background: #2196f3; color: white !important; }
        .btn-logout { background: #f44336; color: white !important; }
        .btn-logout:hover { background: #d32f2f; }
        @media (max-width: 768px) {
            .header { flex-direction: column; text-align: center; }
            .nav-links { justify-content: center; }
        }
        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
        }
        .panel {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        h1 {
            color: #2e7d32;
            margin-bottom: 20px;
        }
        input, textarea {
            width: 100%;
            padding: 12px;
            margin: 8px 0 20px;
            border: 1px solid #ddd;
            border-radius: 12px;
            font-size: 16px;
        }
        button {
            background: #2e7d32;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 30px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover { background: #1b5e20; }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 12px;
            margin-bottom: 20px;
        }
        .footer {
            text-align: center;
            padding: 30px;
            background: white;
            margin-top: 40px;
            border-top: 1px solid #eee;
            color: #666;
        }
    </style>
</head>
<body>

<header class="header">
    <a href="${pageContext.request.contextPath}/" class="logo">Eat<span>&amp;</span>Sip</a>
    <div class="nav-links">
        <a href="${pageContext.request.contextPath}/products">Shop</a>
        <a href="${pageContext.request.contextPath}/about.jsp">About</a>
        <a href="${pageContext.request.contextPath}/contact.jsp">Contact</a>

        <% if (userId == null) { %>
            <a href="${pageContext.request.contextPath}/login.jsp" class="btn-login">Login</a>
            <a href="${pageContext.request.contextPath}/register.jsp" class="btn-register">Register</a>
        <% } else if ("admin".equals(role)) { %>
            <a href="${pageContext.request.contextPath}/admin/dashboard.jsp" class="btn-dashboard">Admin Dashboard</a>
            <a href="${pageContext.request.contextPath}/logout" class="btn-logout">Logout</a>
        <% } else { %>
            <a href="${pageContext.request.contextPath}/customer/dashboard" class="btn-dashboard">My Dashboard</a>
            <a href="${pageContext.request.contextPath}/logout" class="btn-logout">Logout</a>
        <% } %>
    </div>
</header>

<div class="container">
    <div class="panel">
        <h1>Contact Us</h1>
        <% if ("true".equals(submitted)) { %>
            <div class="success">Thank you! Your message has been received.</div>
        <% } %>
        <form action="${pageContext.request.contextPath}/contact" method="post">
            <input type="text" name="fullName" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <input type="text" name="subject" placeholder="Subject" required>
            <textarea name="message" rows="5" placeholder="Your Message..."></textarea>
            <button type="submit">Send Message</button>
        </form>
    </div>
</div>

<div class="footer">
    <p>Email: support@eatandsip.com | Phone: +977-9800000000</p>
    <p>&copy; 2026 Eat&amp;Sip – Fresh Grocery Delivery Platform</p>
</div>

</body>
</html>