<%@ page import="java.util.List" %>
<%@ page import=" com.yellow.eatandsip.model.Product" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%
    List<Product> products = (List<Product>) request.getAttribute("products");
    String keyword = (String) request.getAttribute("keyword");
    String role = (String) session.getAttribute("role");
    Integer userId = (Integer) session.getAttribute("userId");
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eat&Sip - Fresh Groceries</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            color: #1a1a1a;
        }

        /* Header */
        .header {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .top-bar {
            max-width: 1280px;
            margin: 0 auto;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .logo {
            font-size: 28px;
            font-weight: bold;
            color: #2e7d32;
            text-decoration: none;
        }

        .logo span {
            color: #ff9800;
        }

        .search-bar {
            flex: 1;
            max-width: 500px;
            display: flex;
            gap: 10px;
        }

        .search-bar input {
            flex: 1;
            padding: 12px 16px;
            border: 1px solid #e0e0e0;
            border-radius: 30px;
            font-size: 14px;
            outline: none;
            transition: all 0.3s;
        }

        .search-bar input:focus {
            border-color: #2e7d32;
            box-shadow: 0 0 0 2px rgba(46,125,50,0.1);
        }

        .search-bar button {
            background: #2e7d32;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 30px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s;
        }

        .search-bar button:hover {
            background: #1b5e20;
        }

        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
        }

        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-links a:hover {
            color: #2e7d32;
        }

        .btn-login {
            background: #2e7d32;
            color: white !important;
            padding: 8px 20px;
            border-radius: 30px;
        }

        .btn-login:hover {
            background: #1b5e20;
        }

        /* Category Tabs */
        .categories {
            max-width: 1280px;
            margin: 20px auto;
            padding: 0 20px;
            display: flex;
            gap: 15px;
            overflow-x: auto;
            scrollbar-width: thin;
        }

        .category-chip {
            background: white;
            border: 1px solid #e0e0e0;
            padding: 8px 20px;
            border-radius: 40px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            white-space: nowrap;
            transition: all 0.3s;
        }

        .category-chip:hover, .category-chip.active {
            background: #2e7d32;
            color: white;
            border-color: #2e7d32;
        }

        /* Main Container */
        .container {
            max-width: 1280px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Hero Banner */
        .hero {
            background: linear-gradient(135deg, #2e7d32 0%, #4caf50 100%);
            border-radius: 20px;
            padding: 40px 30px;
            margin-bottom: 40px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .hero-text h1 {
            font-size: 36px;
            margin-bottom: 10px;
        }

        .hero-text p {
            font-size: 16px;
            opacity: 0.9;
        }

        .hero-btn {
            background: #ff9800;
            color: white;
            padding: 12px 30px;
            border-radius: 40px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
        }

        /* Product Grid */
        .section-title {
            font-size: 24px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 25px;
        }

        .product-card {
            background: white;
            border-radius: 16px;
            overflow: hidden;
            transition: transform 0.3s, box-shadow 0.3s;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }

        .product-img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            background: #f5f5f5;
        }

        .product-info {
            padding: 16px;
        }

        .product-category {
            font-size: 12px;
            color: #ff9800;
            text-transform: uppercase;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .product-name {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .product-desc {
            font-size: 13px;
            color: #666;
            margin-bottom: 12px;
            line-height: 1.4;
        }

        .product-price {
            font-size: 20px;
            font-weight: bold;
            color: #2e7d32;
            margin-bottom: 10px;
        }

        .product-stock {
            font-size: 12px;
            color: #888;
            margin-bottom: 12px;
        }

        .product-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .btn-order, .btn-wishlist, .btn-notify {
            padding: 8px 16px;
            border-radius: 30px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            font-size: 13px;
            transition: all 0.3s;
        }

        .btn-order {
            background: #2e7d32;
            color: white;
        }

        .btn-order:hover {
            background: #1b5e20;
        }

        .btn-wishlist {
            background: #fff3e0;
            color: #ff9800;
        }

        .btn-wishlist:hover {
            background: #ffe0b2;
        }

        .btn-notify {
            background: #ff9800;
            color: white;
        }

        .quantity-input {
            width: 60px;
            padding: 6px;
            border: 1px solid #ddd;
            border-radius: 20px;
            text-align: center;
        }

        /* Footer */
        .footer {
            background: white;
            padding: 30px 20px;
            text-align: center;
            margin-top: 50px;
            border-top: 1px solid #eee;
            color: #666;
        }

        /* Messages */
        .alert {
            padding: 12px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }

        /* Responsive */
        @media (max-width: 768px) {
            .top-bar { flex-direction: column; align-items: stretch; }
            .search-bar { max-width: 100%; }
            .nav-links { justify-content: center; }
            .hero-text h1 { font-size: 24px; }
        }
    </style>
</head>
<body>
    

<header class="header">
    <div class="top-bar">
        <a href="${pageContext.request.contextPath}/products" class="logo">Eat<span>&amp;</span>Sip</a>
        <form class="search-bar" method="get" action="${pageContext.request.contextPath}/products">
            <input type="text" name="keyword" placeholder="Search for fresh fruits, vegetables, dairy..." value="<%= keyword != null ? keyword : "" %>">
            <button type="submit">Search</button>
        </form>
        <div class="nav-links">
            <a href="${pageContext.request.contextPath}/products">Shop</a>
            <a href="${pageContext.request.contextPath}/about.jsp">About</a>
            <a href="${pageContext.request.contextPath}/contact.jsp">Contact</a>
            <% if (userId == null) { %>
                <a href="${pageContext.request.contextPath}/login.jsp" class="btn-login">Login</a>
                <a href="${pageContext.request.contextPath}/register.jsp">Register</a>
            <% } else if ("admin".equalsIgnoreCase(role)) { %>
                <a href="${pageContext.request.contextPath}/admin/dashboard.jsp">Admin</a>
                <a href="${pageContext.request.contextPath}/logout">Logout</a>
            <% } else { %>
                <a href="${pageContext.request.contextPath}/customer/dashboard">Account</a>
                <a href="${pageContext.request.contextPath}/customer/wishlist">Wishlist</a>
                <a href="${pageContext.request.contextPath}/customer/orders">Orders</a>
                <a href="${pageContext.request.contextPath}/logout">Logout</a>
            <% } %>
        </div>
    </div>
</header>

<div class="container">
    <div class="hero">
        <div class="hero-text">
            <h1>Fresh groceries delivered</h1>
            <p>Get fresh fruits, vegetables, dairy & more at your doorstep</p>
        </div>
        <a href="#" class="hero-btn">Shop Now →</a>
    </div>

    <!-- Category chips (hardcoded for demo) -->
    <div class="categories">
        <span class="category-chip active">All</span>
        <span class="category-chip">Fruits</span>
        <span class="category-chip">Vegetables</span>
        <span class="category-chip">Dairy</span>
        <span class="category-chip">Beverages</span>
        <span class="category-chip">Snacks</span>
    </div>

    <div class="section-title">
        <h2>Today's Fresh Picks</h2>
    </div>

    <% if (request.getParameter("message") != null) { %>
        <div class="alert alert-success"><%= request.getParameter("message") %></div>
    <% } %>
    <% if (request.getParameter("error") != null) { %>
        <div class="alert alert-error"><%= request.getParameter("error") %></div>
    <% } %>

    <div class="product-grid">
        <% if (products == null || products.isEmpty()) { %>
            <p style="grid-column:1/-1; text-align:center;">No products found.</p>
        <% } else {
            for (Product p : products) { %>
                <div class="product-card">
                    <img class="product-img" src="<%= p.getImageUrl() != null ? p.getImageUrl() : "https://via.placeholder.com/300x180?text=No+Image" %>" alt="<%= p.getName() %>">
                    <div class="product-info">
                        <div class="product-category"><%= p.getCategoryName() != null ? p.getCategoryName() : "Grocery" %></div>
                        <div class="product-name"><%= p.getName() %></div>
                        <div class="product-desc"><%= p.getDescription().length() > 60 ? p.getDescription().substring(0,60)+"..." : p.getDescription() %></div>
                        <div class="product-price">Rs. <%= p.getPrice() %></div>
                        <div class="product-stock"><%= p.getStockQuantity() > 0 ? "In Stock ("+p.getStockQuantity()+")" : "Out of Stock" %></div>
                        <div class="product-actions">
                            <% if (userId == null) { %>
                                <a href="${pageContext.request.contextPath}/login.jsp" class="btn-order" style="display:inline-block; text-decoration:none;">Login to Order</a>
                            <% } else if (!"admin".equalsIgnoreCase(role)) { %>
                                <% if (p.getStockQuantity() > 0) { %>
                                    <form action="${pageContext.request.contextPath}/customer/order" method="post" style="display:flex; gap:5px; align-items:center;">
                                        <input type="hidden" name="productId" value="<%= p.getProductId() %>">
                                        <input type="number" name="quantity" value="1" min="1" max="<%= p.getStockQuantity() %>" class="quantity-input">
                                        <button type="submit" class="btn-order">Order</button>
                                    </form>
                                <% } else { %>
                                    <form action="${pageContext.request.contextPath}/customer/requestRestock" method="post">
                                        <input type="hidden" name="productId" value="<%= p.getProductId() %>">
                                        <button type="submit" class="btn-notify">Notify Me</button>
                                    </form>
                                <% } %>
                                <form action="${pageContext.request.contextPath}/customer/wishlist" method="post">
                                    <input type="hidden" name="action" value="add">
                                    <input type="hidden" name="productId" value="<%= p.getProductId() %>">
                                    <button type="submit" class="btn-wishlist">♥ Wishlist</button>
                                </form>
                            <% } %>
                        </div>
                    </div>
                </div>
        <%   }
        } %>
    </div>
</div>

<footer class="footer">
    <p>&copy; 2026 Eat&amp;Sip. Fresh groceries, delivered with care.</p>
</footer>

</body>
</html>