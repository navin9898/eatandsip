<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    Integer userId = (Integer) session.getAttribute("userId");
    String role = (String) session.getAttribute("role");
%>
<!DOCTYPE html>
<html>
<head>
    <title>About Us - Eat&Sip</title>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f8f9fa; }
        .header {
            background: white;
            padding: 15px 7%;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .logo {
            font-size: 28px;
            font-weight: bold;
            color: #2e7d32;
            text-decoration: none;
        }
        .logo span { color: #ff9800; }
        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
            flex-wrap: wrap;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-links a:hover { color: #2e7d32; }
        .btn-login, .btn-register, .btn-dashboard, .btn-logout {
            padding: 8px 16px;
            border-radius: 30px;
            font-weight: 600;
        }
        .btn-login { background: #2e7d32; color: white !important; }
        .btn-login:hover { background: #1b5e20; }
        .btn-register { background: #ff9800; color: white !important; }
        .btn-register:hover { background: #e68900; }
        .btn-dashboard { background: #2196f3; color: white !important; }
        .btn-logout { background: #f44336; color: white !important; }
        .btn-logout:hover { background: #d32f2f; }
        @media (max-width: 768px) {
            .header { flex-direction: column; text-align: center; }
            .nav-links { justify-content: center; }
        }
        .container { max-width: 1100px; margin: 40px auto; padding: 20px; }
        .hero {
            background: linear-gradient(135deg, #2e7d32, #4caf50);
            border-radius: 20px;
            padding: 40px;
            color: white;
            text-align: center;
            margin-bottom: 40px;
        }
        .hero h1 { font-size: 36px; margin-bottom: 10px; }
        .hero p { font-size: 18px; opacity: 0.9; }
        .team-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 30px;
            margin: 40px 0;
        }
        .member {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s;
        }
        .member:hover { transform: translateY(-5px); }
        .member-img {
            width: 100%;
            height: 240px;
            object-fit: cover;
            background: #e0e0e0;
        }
        .member h3 {
            font-size: 22px;
            margin: 18px 0 8px;
            color: #2e7d32;
        }
        .member .role {
            font-size: 16px;
            color: #ff9800;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .member p {
            padding: 0 16px 20px;
            color: #666;
            line-height: 1.5;
        }
        .story {
            background: white;
            border-radius: 20px;
            padding: 30px;
            margin-top: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .story h2 {
            color: #2e7d32;
            margin-bottom: 15px;
            border-left: 4px solid #ff9800;
            padding-left: 15px;
        }
        .story p {
            line-height: 1.6;
            color: #555;
            margin-bottom: 15px;
        }
        .footer {
            text-align: center;
            padding: 30px;
            background: white;
            margin-top: 40px;
            border-top: 1px solid #eee;
            color: #666;
        }
    </style>
</head>
<body>

<header class="header">
    <a href="${pageContext.request.contextPath}/" class="logo">Eat<span>&amp;</span>Sip</a>
    <div class="nav-links">
        <a href="${pageContext.request.contextPath}/products">Shop</a>
        <a href="${pageContext.request.contextPath}/about.jsp">About</a>
        <a href="${pageContext.request.contextPath}/contact.jsp">Contact</a>

        <% if (userId == null) { %>
            <a href="${pageContext.request.contextPath}/login.jsp" class="btn-login">Login</a>
            <a href="${pageContext.request.contextPath}/register.jsp" class="btn-register">Register</a>
        <% } else if ("admin".equals(role)) { %>
            <a href="${pageContext.request.contextPath}/admin/dashboard.jsp" class="btn-dashboard">Admin Dashboard</a>
            <a href="${pageContext.request.contextPath}/logout" class="btn-logout">Logout</a>
        <% } else { %>
            <a href="${pageContext.request.contextPath}/customer/dashboard" class="btn-dashboard">My Dashboard</a>
            <a href="${pageContext.request.contextPath}/logout" class="btn-logout">Logout</a>
        <% } %>
    </div>
</header>

<div class="container">
    <div class="hero">
        <h1>About Eat&amp;Sip</h1>
        <p>Your trusted online grocery store – fresh, fast, and convenient.</p>
    </div>

    <div class="team-grid">
        <div class="member">
            <img class="member-img" src="${pageContext.request.contextPath}/images/team/manil.jpg" alt="Manil Shrestha">
            <h3>Manil Shrestha</h3>
            <div class="role">Founder</div>
            <p>Visionary behind Eat&amp;Sip, dedicated to redefining grocery shopping.</p>
        </div>
        <div class="member">
            <img class="member-img" src="${pageContext.request.contextPath}/images/team/nabin.jpg" alt="Nabin Adhikari">
            <h3>Nabin Adhikari</h3>
            <div class="role">Co‑Founder</div>
            <p>Drives strategy and ensures seamless customer experience.</p>
        </div>
        <div class="member">
            <img class="member-img" src="${pageContext.request.contextPath}/images/team/unik.jpg" alt="Unik Gurung">
            <h3>Unik Gurung</h3>
            <div class="role">Manager</div>
            <p>Oversees daily operations and supply chain excellence.</p>
        </div>
        <div class="member">
            <img class="member-img" src="${pageContext.request.contextPath}/images/team/sanjay.jpg" alt="Sanjay Rana">
            <h3>Sanjay Rana</h3>
            <div class="role">Sales Manager</div>
            <p>Builds strong vendor relationships and customer trust.</p>
        </div>
    </div>

    <div class="story">
        <h2>Our Story</h2>
        <p>Eat&amp;Sip was created to bring farm‑fresh groceries directly to your doorstep. We cut out the middlemen, ensuring you get the best quality at fair prices. From organic vegetables to daily dairy, we partner with local farmers and trusted suppliers.</p>
        <p>Our platform makes ordering easy: browse, click, and we deliver. We're committed to sustainability, freshness, and your satisfaction. Thank you for choosing Eat&amp;Sip – where every meal starts with a smile.</p>
    </div>
</div>

<div class="footer">
    <p>&copy; 2026 Eat&amp;Sip – Fresh Grocery Delivery Platform | Built with Java EE, JSP, MySQL</p>
</div>

</body>
</html>