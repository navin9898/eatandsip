<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Login - Eat&Sip</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f3ea;
            color: #21302a;
        }

        .page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }

        .box {
            width: 100%;
            max-width: 420px;
            background: white;
            padding: 28px;
            border-radius: 8px;
            border: 1px solid #dfd8c8;
            box-shadow: 0 10px 28px rgba(0,0,0,0.12);
        }

        h1 {
            margin: 0 0 8px;
            color: #276749;
        }

        p {
            margin-top: 0;
            color: #68756e;
        }

        label {
            display: block;
            margin-top: 14px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 11px;
            margin-top: 6px;
            border: 1px solid #c8d0c9;
            border-radius: 6px;
            font-size: 15px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            margin-top: 18px;
            padding: 12px;
            background: #276749;
            color: white;
            border: 0;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .error {
            background: #fff1f0;
            color: #9b1c1c;
            border: 1px solid #f3b2ad;
            padding: 10px;
            border-radius: 6px;
            margin: 14px 0;
        }

        .success {
            background: #edf9f1;
            color: #1f6f3f;
            border: 1px solid #a8ddb8;
            padding: 10px;
            border-radius: 6px;
            margin: 14px 0;
        }

        .link {
            text-align: center;
            margin-top: 18px;
        }

        .link a {
            color: #276749;
            font-weight: bold;
        }
    </style>
</head>
<body>
    
<div class="page">
    <div class="box">
        <h1>Eat&amp;Sip</h1>
        <p>Login to continue</p>

        <% if (request.getAttribute("success") != null) { %>
            <div class="success"><%= request.getAttribute("success") %></div>
        <% } %>

        <% if (request.getAttribute("error") != null) { %>
            <div class="error"><%= request.getAttribute("error") %></div>
        <% } %>

        <form action="${pageContext.request.contextPath}/login" method="post">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="${email}" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Login</button>
        </form>

        <div class="link">
            New to Eat&amp;Sip?
            <a href="${pageContext.request.contextPath}/register.jsp">Create account</a>
        </div>
    </div>
</div>
</body>
</html>

